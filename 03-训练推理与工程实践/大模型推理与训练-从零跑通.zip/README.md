# 大模型推理与训练：从零跑通

本包包含：

- `大模型推理与训练-从零跑通.pdf`：91 页技术书，14 章 + 5 个附录；
- `code/`：书中配套的纯 Python / 纯 Go 微型实现、权重、运行日志与 LaTeX 源码；
- `code/tex/`：书稿 LaTeX 源文件与图表数据，可用 Tectonic 重新编译。

## 30 秒跑通

```bash
cd code
./run_all.sh
```

完整跑一遍约 2 分钟（Python 训练约 100 秒，Go 训练约 2 秒）。
所有日志写入 `code/out/`。

如果只想看推理：

```bash
cd code
python3 py/infer.py --temperature 0
cd go && go run ./cmd/infer -weights ../weights/tiny_py.json -temp 0
```

两边都应输出：

```
the cat ran to the log .
```

## 环境

- Python 3.10+（只用标准库）
- Go 1.21+（只用标准库）
- 不需要 GPU、CUDA、PyTorch、NumPy

## 目录

```
.
├── 大模型推理与训练-从零跑通.pdf
├── README.md
└── code/
    ├── py/           # autograd、模型、训练、推理、BPE、SFT/DPO、调度、量化
    ├── go/           # 前向 + KV Cache + 手写反向传播
    ├── data/         # 644 字符玩具语料
    ├── weights/      # 训练产物（tiny_py.json / tiny_go.json）
    ├── out/          # 运行日志
    ├── figures/      # 损失曲线数据
    ├── tex/          # 书稿 LaTeX 源码
    └── run_all.sh
```

详细说明见 `code/README.md`。书中的每个数字都来自这台机器上的真实运行；换机器后绝对时间会变，倍率与结论不变。
