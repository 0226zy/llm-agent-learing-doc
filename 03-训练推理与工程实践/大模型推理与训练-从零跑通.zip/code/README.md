> 本文件位于压缩包的 `code/` 目录内。如果你已经在这个目录，直接运行下面的 `python3`/`go` 命令即可，不需要再 `cd llmbook`。

# 大模型推理与训练：从零跑通（配套代码）

这本书配套一套**无第三方依赖**的微型实现：Python 只用标准库，Go 只用标准库。
模型是一个 1 层、1 头、24 维、6472 个参数的 decoder-only Transformer，结构完整，
小到可以在任何笔记本上跑完。

## 目录

```
llmbook/
├── data/corpus.txt           # 644 字符的玩具语料（16 种字符）
├── py/
│   ├── autograd.py           # 反向模式自动微分（约 300 行）
│   ├── model.py              # 微型 Transformer 的前向
│   ├── train.py              # 训练（AdamW + warmup/cosine）
│   ├── infer.py              # Prefill + KV Cache + 采样
│   ├── neuron.py             # 2 参数神经元的手算/梯度下降
│   ├── bpe.py                # BPE 分词器演示
│   ├── sft_dpo.py            # SFT loss mask 与 DPO loss
│   ├── schedule.py           # 静态 batch vs 连续 batch
│   └── quant.py              # int8 量化对拍
├── go/
│   ├── go.mod
│   ├── tiny/                 # 前向 + KV Cache + 手写反向传播
│   └── cmd/{infer,train,neuron}/
├── weights/                  # 训练产物（JSON）
├── out/                      # 运行日志
└── run_all.sh
```

## 环境

- Python 3.10+（只用标准库）
- Go 1.21+（只用标准库）
- 不需要 GPU、CUDA、PyTorch、NumPy

## 一条命令跑完

```bash
cd llmbook
./run_all.sh
```

完整跑一遍约 2 分钟（Python 训练约 100 秒，Go 训练约 2 秒）。
所有输出同时写入 `out/`。

## 分步跑

### 1. 2 个参数的神经元

```bash
python3 py/neuron.py
cd go && go run ./cmd/neuron
```

两边应打印相同的 10 步表格：`w` 从 0.5 收敛到约 1.299，`b` 从 0 收敛到约 0.400。

### 2. 训练微型 Transformer

```bash
# Python：600 步，约 100 秒，loss 约 0.21
python3 py/train.py --steps 600 --batch 4 --out weights/tiny_py.json

# Go：1200 步，约 2 秒，loss 约 0.21
cd go
go run ./cmd/train -steps 1200 -out ../weights/tiny_go.json
```

训练日志在 `out/train_python.txt`、`out/train_go.txt`。

### 3. 推理（KV Cache）

```bash
# Python，贪心，便于和 Go 对拍
python3 py/infer.py --temperature 0

# Go
cd go
go run ./cmd/infer -weights ../weights/tiny_py.json -temp 0
```

两边都应输出：

```
output: 'the cat ran to the log .'
```

并且逐位置的 `max|cached-full| = 0.000e+00`，说明缓存与全量重算完全一致。

### 4. 分词、SFT/DPO、调度、量化

```bash
python3 py/bpe.py
python3 py/sft_dpo.py
python3 py/schedule.py
python3 py/quant.py
```

## 你可以改什么

- `py/infer.py --prompt "the dog " --temperature 0.7 --top-k 6`
- `py/train.py --steps 1200 --batch 8`：观察 loss 曲线
- `py/model.py` 里把 `n_layer` 改成 2：参数量翻倍，训练变慢，但结构不变
- `py/quant.py` 里把 `per_channel` 改成 `True`：观察 top-1 是否保持
- `py/schedule.py` 里改请求长度分布：观察静态/连续 batch 的利用率

## 说明

这是教学实现，不是生产推理引擎：

- 纯 Python/Go 的矩阵乘、float64、无 SIMD/GPU，速度比 vLLM/llama.cpp 慢几个数量级；
- 单头、单层、字符级 tokenizer，是为了让每个数字可手算；
- 没有 PagedAttention、连续批处理、量化 kernel、CUDA graph；
- 但**数学流程与生产系统一致**：同样的 QKV、softmax、残差、LayerNorm、交叉熵、AdamW、KV Cache。

生产系统的工程细节见第 8、12、13 章。
