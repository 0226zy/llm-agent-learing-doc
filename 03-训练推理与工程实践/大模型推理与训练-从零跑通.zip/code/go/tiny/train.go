package tiny

import (
	"encoding/json"
	"math"
	"os"
)

// ---------------------------------------------------------------------------
// matrix helpers
// ---------------------------------------------------------------------------
func MatMul(a, b Matrix) Matrix {
	if a.Cols != b.Rows {
		panic("matmul shape mismatch")
	}
	out := NewMatrix(a.Rows, b.Cols)
	for i := 0; i < a.Rows; i++ {
		ai := a.Row(i)
		oi := out.Row(i)
		for k := 0; k < a.Cols; k++ {
			v := ai[k]
			if v == 0 {
				continue
			}
			bk := b.Row(k)
			for j := 0; j < b.Cols; j++ {
				oi[j] += v * bk[j]
			}
		}
	}
	return out
}

func Transpose(a Matrix) Matrix {
	out := NewMatrix(a.Cols, a.Rows)
	for i := 0; i < a.Rows; i++ {
		for j := 0; j < a.Cols; j++ {
			out.Set(j, i, a.At(i, j))
		}
	}
	return out
}

func CopyMat(a Matrix) Matrix {
	out := NewMatrix(a.Rows, a.Cols)
	copy(out.Data, a.Data)
	return out
}

func ScaleMat(a Matrix, s float64) Matrix {
	out := NewMatrix(a.Rows, a.Cols)
	for i, v := range a.Data {
		out.Data[i] = v * s
	}
	return out
}

func AddMat(a, b Matrix) Matrix {
	out := NewMatrix(a.Rows, a.Cols)
	for i := range a.Data {
		out.Data[i] = a.Data[i] + b.Data[i]
	}
	return out
}

func ColSum(a Matrix) Vector {
	out := make(Vector, a.Cols)
	for i := 0; i < a.Rows; i++ {
		for j := 0; j < a.Cols; j++ {
			out[j] += a.At(i, j)
		}
	}
	return out
}

func zeroMatrix(rows, cols int) Matrix { return NewMatrix(rows, cols) }
func zeroVector(n int) Vector          { return make(Vector, n) }

// ---------------------------------------------------------------------------
// parameter init
// ---------------------------------------------------------------------------
func gaussian(rng *RNG) float64 {
	u1 := rng.Float64()
	if u1 < 1e-12 {
		u1 = 1e-12
	}
	u2 := rng.Float64()
	return math.Sqrt(-2*math.Log(u1)) * math.Cos(2*math.Pi*u2)
}

func randomMatrix(rng *RNG, rows, cols int, std float64) Matrix {
	m := NewMatrix(rows, cols)
	for i := range m.Data {
		m.Data[i] = gaussian(rng) * std
	}
	return m
}

func InitWeights(cfg Config, seed uint64) *Weights {
	rng := NewRNG(seed)
	std := 1.0 / math.Sqrt(float64(cfg.NEmbd))
	mat := func(r, c int, s float64) Matrix { return randomMatrix(rng, r, c, s) }
	vec := func(n int, v float64) Vector {
		out := make(Vector, n)
		for i := range out {
			out[i] = v
		}
		return out
	}
	return &Weights{
		TokEmb: mat(cfg.VocabSize, cfg.NEmbd, 0.02),
		PosEmb: mat(cfg.BlockSize, cfg.NEmbd, 0.01),
		Ln1G:   vec(cfg.NEmbd, 1), Ln1B: vec(cfg.NEmbd, 0),
		Wq: mat(cfg.NEmbd, cfg.NEmbd, std), Bq: vec(cfg.NEmbd, 0),
		Wk: mat(cfg.NEmbd, cfg.NEmbd, std), Bk: vec(cfg.NEmbd, 0),
		Wv: mat(cfg.NEmbd, cfg.NEmbd, std), Bv: vec(cfg.NEmbd, 0),
		Wo: mat(cfg.NEmbd, cfg.NEmbd, std), Bo: vec(cfg.NEmbd, 0),
		Ln2G: vec(cfg.NEmbd, 1), Ln2B: vec(cfg.NEmbd, 0),
		W1: mat(cfg.NEmbd, cfg.DFF, std), B1: vec(cfg.DFF, 0),
		W2: mat(cfg.DFF, cfg.NEmbd, std), B2: vec(cfg.NEmbd, 0),
		LnfG: vec(cfg.NEmbd, 1), LnfB: vec(cfg.NEmbd, 0),
		LmHead: mat(cfg.NEmbd, cfg.VocabSize, std), LmB: vec(cfg.VocabSize, 0),
	}
}

func ZeroGrads(g *Weights) {
	zeroM := func(m Matrix) {
		for i := range m.Data {
			m.Data[i] = 0
		}
	}
	zeroV := func(v Vector) {
		for i := range v {
			v[i] = 0
		}
	}
	zeroM(g.TokEmb)
	zeroM(g.PosEmb)
	zeroV(g.Ln1G)
	zeroV(g.Ln1B)
	zeroM(g.Wq)
	zeroV(g.Bq)
	zeroM(g.Wk)
	zeroV(g.Bk)
	zeroM(g.Wv)
	zeroV(g.Bv)
	zeroM(g.Wo)
	zeroV(g.Bo)
	zeroV(g.Ln2G)
	zeroV(g.Ln2B)
	zeroM(g.W1)
	zeroV(g.B1)
	zeroM(g.W2)
	zeroV(g.B2)
	zeroV(g.LnfG)
	zeroV(g.LnfB)
	zeroM(g.LmHead)
	zeroV(g.LmB)
}

func newGradsLike(p *Weights) *Weights {
	m := func(x Matrix) Matrix { return zeroMatrix(x.Rows, x.Cols) }
	v := func(x Vector) Vector { return zeroVector(len(x)) }
	return &Weights{
		TokEmb: m(p.TokEmb), PosEmb: m(p.PosEmb),
		Ln1G: v(p.Ln1G), Ln1B: v(p.Ln1B),
		Wq: m(p.Wq), Bq: v(p.Bq), Wk: m(p.Wk), Bk: v(p.Bk),
		Wv: m(p.Wv), Bv: v(p.Bv), Wo: m(p.Wo), Bo: v(p.Bo),
		Ln2G: v(p.Ln2G), Ln2B: v(p.Ln2B),
		W1: m(p.W1), B1: v(p.B1), W2: m(p.W2), B2: v(p.B2),
		LnfG: v(p.LnfG), LnfB: v(p.LnfB), LmHead: m(p.LmHead), LmB: v(p.LmB),
	}
}

// ---------------------------------------------------------------------------
// forward cache
// ---------------------------------------------------------------------------
type Cache struct {
	X0, H1, Q, K, V Matrix
	Scores, Attn    Matrix
	AO, X1          Matrix
	H2, H3Pre, H3   Matrix
	H4, X2, Hf      Matrix
	Logits, Probs   Matrix
}

func (m *Model) forwardTrain(p *Weights, ids []int) *Cache {
	t, d := len(ids), m.Config.NEmbd
	c := &Cache{}
	c.X0 = NewMatrix(t, d)
	for i, id := range ids {
		for j := 0; j < d; j++ {
			c.X0.Set(i, j, p.TokEmb.At(id, j)+p.PosEmb.At(i, j))
		}
	}
	c.H1 = LayerNorm(c.X0, p.Ln1G, p.Ln1B, 1e-5)
	c.Q = Linear(c.H1, p.Wq, p.Bq)
	c.K = Linear(c.H1, p.Wk, p.Bk)
	c.V = Linear(c.H1, p.Wv, p.Bv)
	c.Scores = NewMatrix(t, t)
	scale := 1.0 / math.Sqrt(float64(d))
	for i := 0; i < t; i++ {
		for j := 0; j < t; j++ {
			if j > i {
				c.Scores.Set(i, j, -1e30)
				continue
			}
			s := 0.0
			for z := 0; z < d; z++ {
				s += c.Q.At(i, z) * c.K.At(j, z)
			}
			c.Scores.Set(i, j, s*scale)
		}
	}
	c.Attn = NewMatrix(t, t)
	for i := 0; i < t; i++ {
		p := Softmax(c.Scores.Row(i))
		for j := 0; j < t; j++ {
			c.Attn.Set(i, j, p[j])
		}
	}
	c.AO = MatMul(c.Attn, c.V)
	y := Linear(c.AO, p.Wo, p.Bo)
	c.X1 = AddRows(c.X0, y)
	c.H2 = LayerNorm(c.X1, p.Ln2G, p.Ln2B, 1e-5)
	c.H3Pre = Linear(c.H2, p.W1, p.B1)
	c.H3 = Relu(c.H3Pre)
	c.H4 = Linear(c.H3, p.W2, p.B2)
	c.X2 = AddRows(c.X1, c.H4)
	c.Hf = LayerNorm(c.X2, p.LnfG, p.LnfB, 1e-5)
	c.Logits = Linear(c.Hf, p.LmHead, p.LmB)
	c.Probs = NewMatrix(t, m.Config.VocabSize)
	for i := 0; i < t; i++ {
		p := Softmax(c.Logits.Row(i))
		for j := 0; j < m.Config.VocabSize; j++ {
			c.Probs.Set(i, j, p[j])
		}
	}
	return c
}

// LayerNormBackward returns dx and accumulates dg/db.
func LayerNormBackward(x Matrix, gamma Vector, dy Matrix, dg, db Vector, eps float64) Matrix {
	dx := NewMatrix(x.Rows, x.Cols)
	for r := 0; r < x.Rows; r++ {
		row := x.Row(r)
		mean := 0.0
		for _, v := range row {
			mean += v
		}
		mean /= float64(len(row))
		variance := 0.0
		for _, v := range row {
			d := v - mean
			variance += d * d
		}
		variance /= float64(len(row))
		inv := 1.0 / math.Sqrt(variance+eps)
		n := float64(len(row))
		dxhat := make([]float64, len(row))
		s1, s2 := 0.0, 0.0
		for i, v := range row {
			xh := (v - mean) * inv
			dxhat[i] = dy.At(r, i) * gamma[i]
			s1 += dxhat[i]
			s2 += dxhat[i] * xh
		}
		for i, v := range row {
			xh := (v - mean) * inv
			dx.Set(r, i, inv/n*(n*dxhat[i]-s1-xh*s2))
			dg[i] += dy.At(r, i) * xh
			db[i] += dy.At(r, i)
		}
	}
	return dx
}

// BackwardTrain accumulates gradients and returns the mean loss.
func (m *Model) BackwardTrain(p, g *Weights, c *Cache, ids, targets []int) float64 {
	t, v := len(targets), m.Config.VocabSize
	loss := 0.0
	dlogits := NewMatrix(t, v)
	for i := 0; i < t; i++ {
		loss -= math.Log(c.Probs.At(i, targets[i]) + 1e-12)
		for j := 0; j < v; j++ {
			dlogits.Set(i, j, c.Probs.At(i, j))
		}
		dlogits.Set(i, targets[i], dlogits.At(i, targets[i])-1)
	}
	loss /= float64(t)
	for i := range dlogits.Data {
		dlogits.Data[i] /= float64(t)
	}

	g.LmHead = AddMat(g.LmHead, MatMul(Transpose(c.Hf), dlogits))
	g.LmB = addVec(g.LmB, ColSum(dlogits))
	dhf := MatMul(dlogits, Transpose(p.LmHead))
	dx2 := LayerNormBackward(c.X2, p.LnfG, dhf, g.LnfG, g.LnfB, 1e-5)

	dx1 := CopyMat(dx2)
	g.W2 = AddMat(g.W2, MatMul(Transpose(c.H3), dx2))
	g.B2 = addVec(g.B2, ColSum(dx2))
	dh3 := MatMul(dx2, Transpose(p.W2))
	dh2 := NewMatrix(t, m.Config.DFF)
	for i := range dh2.Data {
		if c.H3Pre.Data[i] > 0 {
			dh2.Data[i] = dh3.Data[i]
		}
	}
	g.W1 = AddMat(g.W1, MatMul(Transpose(c.H2), dh2))
	g.B1 = addVec(g.B1, ColSum(dh2))
	dh2in := MatMul(dh2, Transpose(p.W1))
	dx1 = AddMat(dx1, LayerNormBackward(c.X1, p.Ln2G, dh2in, g.Ln2G, g.Ln2B, 1e-5))

	dx0 := CopyMat(dx1)
	g.Wo = AddMat(g.Wo, MatMul(Transpose(c.AO), dx1))
	g.Bo = addVec(g.Bo, ColSum(dx1))
	dao := MatMul(dx1, Transpose(p.Wo))

	// attention backward
	dV := MatMul(Transpose(c.Attn), dao)
	dAttn := MatMul(dao, Transpose(c.V))
	dScores := NewMatrix(t, t)
	scale := 1.0 / math.Sqrt(float64(m.Config.NEmbd))
	for i := 0; i < t; i++ {
		dot := 0.0
		for j := 0; j < t; j++ {
			dot += dAttn.At(i, j) * c.Attn.At(i, j)
		}
		for j := 0; j < t; j++ {
			if j > i {
				continue
			}
			dScores.Set(i, j, c.Attn.At(i, j)*(dAttn.At(i, j)-dot)*scale)
		}
	}
	dQ := MatMul(dScores, c.K)
	dK := MatMul(Transpose(dScores), c.Q)

	g.Wq = AddMat(g.Wq, MatMul(Transpose(c.H1), dQ))
	g.Bq = addVec(g.Bq, ColSum(dQ))
	g.Wk = AddMat(g.Wk, MatMul(Transpose(c.H1), dK))
	g.Bk = addVec(g.Bk, ColSum(dK))
	g.Wv = AddMat(g.Wv, MatMul(Transpose(c.H1), dV))
	g.Bv = addVec(g.Bv, ColSum(dV))
	dh1 := MatMul(dQ, Transpose(p.Wq))
	dh1 = AddMat(dh1, MatMul(dK, Transpose(p.Wk)))
	dh1 = AddMat(dh1, MatMul(dV, Transpose(p.Wv)))
	dx0 = AddMat(dx0, LayerNormBackward(c.X0, p.Ln1G, dh1, g.Ln1G, g.Ln1B, 1e-5))

	for i, id := range ids {
		for j := 0; j < m.Config.NEmbd; j++ {
			g.TokEmb.Data[id*m.Config.NEmbd+j] += dx0.At(i, j)
			g.PosEmb.Data[i*m.Config.NEmbd+j] += dx0.At(i, j)
		}
	}
	return loss
}

func addVec(a, b Vector) Vector {
	out := make(Vector, len(a))
	for i := range a {
		out[i] = a[i] + b[i]
	}
	return out
}

// ---------------------------------------------------------------------------
// AdamW and training
// ---------------------------------------------------------------------------
func adamMatrix(p, g, m, v Matrix, lr float64, step int, wd float64) {
	b1, b2 := 0.9, 0.95
	bc1 := 1 - math.Pow(b1, float64(step))
	bc2 := 1 - math.Pow(b2, float64(step))
	for i := range p.Data {
		gi := g.Data[i]
		m.Data[i] = b1*m.Data[i] + (1-b1)*gi
		v.Data[i] = b2*v.Data[i] + (1-b2)*gi*gi
		mh := m.Data[i] / bc1
		vh := v.Data[i] / bc2
		p.Data[i] -= lr * (mh/(math.Sqrt(vh)+1e-8) + wd*p.Data[i])
	}
}

func adamVector(p, g, m, v Vector, lr float64, step int, wd float64) {
	b1, b2 := 0.9, 0.95
	bc1 := 1 - math.Pow(b1, float64(step))
	bc2 := 1 - math.Pow(b2, float64(step))
	for i := range p {
		gi := g[i]
		m[i] = b1*m[i] + (1-b1)*gi
		v[i] = b2*v[i] + (1-b2)*gi*gi
		mh := m[i] / bc1
		vh := v[i] / bc2
		p[i] -= lr * (mh/(math.Sqrt(vh)+1e-8) + wd*p[i])
	}
}

func (m *Model) AdamStep(p, g, mom, vel *Weights, lr float64, step int) {
	wd := 0.01
	adamMatrix(p.TokEmb, g.TokEmb, mom.TokEmb, vel.TokEmb, lr, step, wd)
	adamMatrix(p.PosEmb, g.PosEmb, mom.PosEmb, vel.PosEmb, lr, step, wd)
	adamVector(p.Ln1G, g.Ln1G, mom.Ln1G, vel.Ln1G, lr, step, wd)
	adamVector(p.Ln1B, g.Ln1B, mom.Ln1B, vel.Ln1B, lr, step, wd)
	adamMatrix(p.Wq, g.Wq, mom.Wq, vel.Wq, lr, step, wd)
	adamVector(p.Bq, g.Bq, mom.Bq, vel.Bq, lr, step, wd)
	adamMatrix(p.Wk, g.Wk, mom.Wk, vel.Wk, lr, step, wd)
	adamVector(p.Bk, g.Bk, mom.Bk, vel.Bk, lr, step, wd)
	adamMatrix(p.Wv, g.Wv, mom.Wv, vel.Wv, lr, step, wd)
	adamVector(p.Bv, g.Bv, mom.Bv, vel.Bv, lr, step, wd)
	adamMatrix(p.Wo, g.Wo, mom.Wo, vel.Wo, lr, step, wd)
	adamVector(p.Bo, g.Bo, mom.Bo, vel.Bo, lr, step, wd)
	adamVector(p.Ln2G, g.Ln2G, mom.Ln2G, vel.Ln2G, lr, step, wd)
	adamVector(p.Ln2B, g.Ln2B, mom.Ln2B, vel.Ln2B, lr, step, wd)
	adamMatrix(p.W1, g.W1, mom.W1, vel.W1, lr, step, wd)
	adamVector(p.B1, g.B1, mom.B1, vel.B1, lr, step, wd)
	adamMatrix(p.W2, g.W2, mom.W2, vel.W2, lr, step, wd)
	adamVector(p.B2, g.B2, mom.B2, vel.B2, lr, step, wd)
	adamVector(p.LnfG, g.LnfG, mom.LnfG, vel.LnfG, lr, step, wd)
	adamVector(p.LnfB, g.LnfB, mom.LnfB, vel.LnfB, lr, step, wd)
	adamMatrix(p.LmHead, g.LmHead, mom.LmHead, vel.LmHead, lr, step, wd)
	adamVector(p.LmB, g.LmB, mom.LmB, vel.LmB, lr, step, wd)
}

func (g *Weights) GlobalNorm() float64 {
	sum := 0.0
	addM := func(m Matrix) {
		for _, v := range m.Data {
			sum += v * v
		}
	}
	addV := func(v Vector) {
		for _, x := range v {
			sum += x * x
		}
	}
	addM(g.TokEmb)
	addM(g.PosEmb)
	addV(g.Ln1G)
	addV(g.Ln1B)
	addM(g.Wq)
	addV(g.Bq)
	addM(g.Wk)
	addV(g.Bk)
	addM(g.Wv)
	addV(g.Bv)
	addM(g.Wo)
	addV(g.Bo)
	addV(g.Ln2G)
	addV(g.Ln2B)
	addM(g.W1)
	addV(g.B1)
	addM(g.W2)
	addV(g.B2)
	addV(g.LnfG)
	addV(g.LnfB)
	addM(g.LmHead)
	addV(g.LmB)
	return math.Sqrt(sum)
}

func (g *Weights) Scale(s float64) {
	scaleM := func(m Matrix) {
		for i := range m.Data {
			m.Data[i] *= s
		}
	}
	scaleV := func(v Vector) {
		for i := range v {
			v[i] *= s
		}
	}
	scaleM(g.TokEmb)
	scaleM(g.PosEmb)
	scaleV(g.Ln1G)
	scaleV(g.Ln1B)
	scaleM(g.Wq)
	scaleV(g.Bq)
	scaleM(g.Wk)
	scaleV(g.Bk)
	scaleM(g.Wv)
	scaleV(g.Bv)
	scaleM(g.Wo)
	scaleV(g.Bo)
	scaleV(g.Ln2G)
	scaleV(g.Ln2B)
	scaleM(g.W1)
	scaleV(g.B1)
	scaleM(g.W2)
	scaleV(g.B2)
	scaleV(g.LnfG)
	scaleV(g.LnfB)
	scaleM(g.LmHead)
	scaleV(g.LmB)
}

type saveTensor struct {
	Shape []int     `json:"shape"`
	Data  []float64 `json:"data"`
}

type saveModel struct {
	Config  Config                `json:"config"`
	Vocab   []string              `json:"vocab"`
	Weights map[string]saveTensor `json:"weights"`
}

func (m *Model) Save(path string, vocab []string, p *Weights) error {
	obj := saveModel{Config: m.Config, Vocab: vocab, Weights: map[string]saveTensor{}}
	add := func(name string, mat Matrix) {
		obj.Weights[name] = saveTensor{Shape: []int{mat.Rows, mat.Cols}, Data: mat.Data}
	}
	addV := func(name string, vec Vector) {
		obj.Weights[name] = saveTensor{Shape: []int{len(vec)}, Data: vec}
	}
	add("tok_emb", p.TokEmb)
	add("pos_emb", p.PosEmb)
	addV("ln1_g", p.Ln1G)
	addV("ln1_b", p.Ln1B)
	add("wq", p.Wq)
	addV("bq", p.Bq)
	add("wk", p.Wk)
	addV("bk", p.Bk)
	add("wv", p.Wv)
	addV("bv", p.Bv)
	add("wo", p.Wo)
	addV("bo", p.Bo)
	addV("ln2_g", p.Ln2G)
	addV("ln2_b", p.Ln2B)
	add("w1", p.W1)
	addV("b1", p.B1)
	add("w2", p.W2)
	addV("b2", p.B2)
	addV("lnf_g", p.LnfG)
	addV("lnf_b", p.LnfB)
	add("lm_head", p.LmHead)
	addV("lm_b", p.LmB)
	b, err := json.Marshal(obj)
	if err != nil {
		return err
	}
	return os.WriteFile(path, b, 0o644)
}

// ForwardNoCache returns the logits for a full sequence (used by sampling).
func (m *Model) ForwardNoCache(p *Weights, ids []int) []float64 {
	c := m.forwardTrain(p, ids)
	return c.Logits.Row(c.Logits.Rows - 1)
}

// TrainStep runs one forward/backward pass and accumulates gradients.
func (m *Model) TrainStep(p, g *Weights, ids, targets []int) float64 {
	c := m.forwardTrain(p, ids)
	return m.BackwardTrain(p, g, c, ids, targets)
}

// Loss evaluates the mean cross-entropy without touching gradients.
func (m *Model) Loss(p *Weights, ids, targets []int) float64 {
	c := m.forwardTrain(p, ids)
	loss := 0.0
	for i, t := range targets {
		loss -= math.Log(c.Probs.At(i, t) + 1e-12)
	}
	return loss / float64(len(targets))
}

// Generate samples up to n tokens. It stops after stopID once minTokens is reached.
func (m *Model) Generate(p *Weights, prompt []int, n int, temperature float64,
	topK int, stopID int, minTokens int, rng *RNG) []int {
	ids := append([]int{}, prompt...)
	for step := 0; step < n; step++ {
		ctx := ids
		if len(ctx) > m.Config.BlockSize {
			ctx = ctx[len(ctx)-m.Config.BlockSize:]
		}
		logits := m.ForwardNoCache(p, ctx)
		nxt, _ := SampleTop(logits, temperature, topK, 1.0, rng)
		ids = append(ids, nxt)
		if nxt == stopID && len(ids)-len(prompt) >= minTokens {
			break
		}
	}
	return ids
}
