package tiny

import (
	"math"
	"testing"
)

func TestGradients(t *testing.T) {
	cfg := Config{VocabSize: 16, BlockSize: 8, NLayer: 1, NHead: 1, NEmbd: 24, DFF: 48}
	p := InitWeights(cfg, 42)
	g := InitWeights(cfg, 0)
	ZeroGrads(g)
	m := &Model{Config: cfg}
	ids := []int{1, 2, 3, 4, 5, 6, 7, 8}
	targets := []int{2, 3, 4, 5, 6, 7, 8, 9}
	m.TrainStep(p, g, ids, targets)

	checkM := func(name string, mat Matrix, grad Matrix) {
		for _, idx := range []int{0, 1, 17, 100} {
			if idx >= len(mat.Data) {
				continue
			}
			old := mat.Data[idx]
			mat.Data[idx] = old + 1e-5
			l1 := m.Loss(p, ids, targets)
			mat.Data[idx] = old - 1e-5
			l2 := m.Loss(p, ids, targets)
			mat.Data[idx] = old
			num := (l1 - l2) / 2e-5
			ana := grad.Data[idx]
			den := math.Max(1e-8, math.Abs(num)+math.Abs(ana))
			if math.Abs(num-ana)/den > 2e-4 {
				t.Errorf("%s[%d]: analytic %.8f numeric %.8f", name, idx, ana, num)
			}
		}
	}
	checkV := func(name string, vec Vector, grad Vector) {
		for _, idx := range []int{0, 1, 7} {
			if idx >= len(vec) {
				continue
			}
			old := vec[idx]
			vec[idx] = old + 1e-5
			l1 := m.Loss(p, ids, targets)
			vec[idx] = old - 1e-5
			l2 := m.Loss(p, ids, targets)
			vec[idx] = old
			num := (l1 - l2) / 2e-5
			ana := grad[idx]
			den := math.Max(1e-8, math.Abs(num)+math.Abs(ana))
			if math.Abs(num-ana)/den > 2e-4 {
				t.Errorf("%s[%d]: analytic %.8f numeric %.8f", name, idx, ana, num)
			}
		}
	}
	checkM("tok_emb", p.TokEmb, g.TokEmb)
	checkM("pos_emb", p.PosEmb, g.PosEmb)
	checkM("wq", p.Wq, g.Wq)
	checkM("wk", p.Wk, g.Wk)
	checkM("wv", p.Wv, g.Wv)
	checkM("wo", p.Wo, g.Wo)
	checkM("w1", p.W1, g.W1)
	checkM("w2", p.W2, g.W2)
	checkM("lm_head", p.LmHead, g.LmHead)
	checkV("ln1_g", p.Ln1G, g.Ln1G)
	checkV("ln1_b", p.Ln1B, g.Ln1B)
	checkV("ln2_g", p.Ln2G, g.Ln2G)
	checkV("lnf_g", p.LnfG, g.LnfG)
	checkV("bq", p.Bq, g.Bq)
	checkV("b1", p.B1, g.B1)
}
