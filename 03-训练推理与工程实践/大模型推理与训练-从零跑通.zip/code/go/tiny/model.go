// Package tiny implements a one-layer, one-head decoder-only Transformer.
// It is deliberately written with plain slices so every multiply is visible.
package tiny

import (
	"encoding/json"
	"fmt"
	"math"
	"os"
)

type Config struct {
	VocabSize int     `json:"vocab_size"`
	BlockSize int     `json:"block_size"`
	NLayer    int     `json:"n_layer"`
	NHead     int     `json:"n_head"`
	NEmbd     int     `json:"n_embd"`
	DFF       int     `json:"d_ff"`
	Dropout   float64 `json:"dropout"`
}

type Matrix struct {
	Rows, Cols int
	Data       []float64
}

func NewMatrix(rows, cols int) Matrix {
	return Matrix{Rows: rows, Cols: cols, Data: make([]float64, rows*cols)}
}

func (m Matrix) At(r, c int) float64     { return m.Data[r*m.Cols+c] }
func (m Matrix) Set(r, c int, v float64) { m.Data[r*m.Cols+c] = v }
func (m Matrix) Row(r int) []float64     { return m.Data[r*m.Cols : (r+1)*m.Cols] }

type Vector []float64

type Weights struct {
	TokEmb, PosEmb Matrix
	Ln1G, Ln1B     Vector
	Wq             Matrix
	Bq             Vector
	Wk             Matrix
	Bk             Vector
	Wv             Matrix
	Bv             Vector
	Wo             Matrix
	Bo             Vector
	Ln2G, Ln2B     Vector
	W1             Matrix
	B1             Vector
	W2             Matrix
	B2             Vector
	LnfG, LnfB     Vector
	LmHead         Matrix
	LmB            Vector
}

type tensorJSON struct {
	Shape []int     `json:"shape"`
	Data  []float64 `json:"data"`
}

type modelJSON struct {
	Config  Config                `json:"config"`
	Vocab   []string              `json:"vocab"`
	Weights map[string]tensorJSON `json:"weights"`
}

type Model struct {
	Config Config
	Vocab  []string
	W      Weights
}

func loadMatrix(m map[string]tensorJSON, name string) (Matrix, error) {
	t, ok := m[name]
	if !ok {
		return Matrix{}, fmt.Errorf("missing weight %q", name)
	}
	if len(t.Shape) != 2 {
		return Matrix{}, fmt.Errorf("weight %q is not a matrix", name)
	}
	r, c := t.Shape[0], t.Shape[1]
	if len(t.Data) != r*c {
		return Matrix{}, fmt.Errorf("weight %q shape mismatch", name)
	}
	return Matrix{Rows: r, Cols: c, Data: t.Data}, nil
}

func loadVector(m map[string]tensorJSON, name string) (Vector, error) {
	t, ok := m[name]
	if !ok {
		return nil, fmt.Errorf("missing weight %q", name)
	}
	if len(t.Shape) != 1 {
		return nil, fmt.Errorf("weight %q is not a vector", name)
	}
	if len(t.Data) != t.Shape[0] {
		return nil, fmt.Errorf("weight %q shape mismatch", name)
	}
	return Vector(t.Data), nil
}

func Load(path string) (*Model, error) {
	b, err := os.ReadFile(path)
	if err != nil {
		return nil, err
	}
	var obj modelJSON
	if err := json.Unmarshal(b, &obj); err != nil {
		return nil, err
	}
	mdl := &Model{Config: obj.Config, Vocab: obj.Vocab}
	getM := func(name string) Matrix {
		m, err := loadMatrix(obj.Weights, name)
		if err != nil {
			panic(err)
		}
		return m
	}
	getV := func(name string) Vector {
		v, err := loadVector(obj.Weights, name)
		if err != nil {
			panic(err)
		}
		return v
	}
	mdl.W = Weights{
		TokEmb: getM("tok_emb"), PosEmb: getM("pos_emb"),
		Ln1G: getV("ln1_g"), Ln1B: getV("ln1_b"),
		Wq: getM("wq"), Bq: getV("bq"),
		Wk: getM("wk"), Bk: getV("bk"),
		Wv: getM("wv"), Bv: getV("bv"),
		Wo: getM("wo"), Bo: getV("bo"),
		Ln2G: getV("ln2_g"), Ln2B: getV("ln2_b"),
		W1: getM("w1"), B1: getV("b1"),
		W2: getM("w2"), B2: getV("b2"),
		LnfG: getV("lnf_g"), LnfB: getV("lnf_b"),
		LmHead: getM("lm_head"), LmB: getV("lm_b"),
	}
	return mdl, nil
}

func (m *Model) ParamCount() int {
	return len(m.W.TokEmb.Data) + len(m.W.PosEmb.Data) +
		len(m.W.Ln1G) + len(m.W.Ln1B) +
		len(m.W.Wq.Data) + len(m.W.Bq) + len(m.W.Wk.Data) + len(m.W.Bk) +
		len(m.W.Wv.Data) + len(m.W.Bv) + len(m.W.Wo.Data) + len(m.W.Bo) +
		len(m.W.Ln2G) + len(m.W.Ln2B) +
		len(m.W.W1.Data) + len(m.W.B1) + len(m.W.W2.Data) + len(m.W.B2) +
		len(m.W.LnfG) + len(m.W.LnfB) + len(m.W.LmHead.Data) + len(m.W.LmB)
}

// Linear computes X*W + b. X is n x d, W is d x out.
func Linear(x Matrix, w Matrix, b Vector) Matrix {
	out := NewMatrix(x.Rows, w.Cols)
	for i := 0; i < x.Rows; i++ {
		xi := x.Row(i)
		oi := out.Row(i)
		for k := 0; k < x.Cols; k++ {
			a := xi[k]
			if a == 0 {
				continue
			}
			wk := w.Row(k)
			for j := 0; j < w.Cols; j++ {
				oi[j] += a * wk[j]
			}
		}
		for j := 0; j < w.Cols; j++ {
			oi[j] += b[j]
		}
	}
	return out
}

func LayerNorm(x Matrix, g, b Vector, eps float64) Matrix {
	out := NewMatrix(x.Rows, x.Cols)
	for r := 0; r < x.Rows; r++ {
		row := x.Row(r)
		mean := 0.0
		for _, v := range row {
			mean += v
		}
		mean /= float64(len(row))
		variance := 0.0
		for _, v := range row {
			d := v - mean
			variance += d * d
		}
		variance /= float64(len(row))
		inv := 1.0 / math.Sqrt(variance+eps)
		o := out.Row(r)
		for i, v := range row {
			o[i] = (v-mean)*inv*g[i] + b[i]
		}
	}
	return out
}

func Softmax(row []float64) []float64 {
	mx := row[0]
	for _, v := range row[1:] {
		if v > mx {
			mx = v
		}
	}
	ex := make([]float64, len(row))
	s := 0.0
	for i, v := range row {
		ex[i] = math.Exp(v - mx)
		s += ex[i]
	}
	for i := range ex {
		ex[i] /= s
	}
	return ex
}

func Relu(x Matrix) Matrix {
	out := NewMatrix(x.Rows, x.Cols)
	for i, v := range x.Data {
		if v > 0 {
			out.Data[i] = v
		}
	}
	return out
}

func AddRows(a, b Matrix) Matrix {
	out := NewMatrix(a.Rows, a.Cols)
	for i := range a.Data {
		out.Data[i] = a.Data[i] + b.Data[i]
	}
	return out
}

func Embed(table Matrix, ids []int) Matrix {
	out := NewMatrix(len(ids), table.Cols)
	for i, id := range ids {
		copy(out.Row(i), table.Row(id))
	}
	return out
}

type KVCache struct {
	K, V [][]float64
}

func (c *KVCache) SeqLen() int { return len(c.K) }

func (c *KVCache) Bytes(perValue int) int {
	if len(c.K) == 0 {
		return 0
	}
	return 2 * len(c.K) * len(c.K[0]) * perValue
}

func (m *Model) qkv(x Matrix) (Matrix, Matrix, Matrix) {
	return Linear(x, m.W.Wq, m.W.Bq),
		Linear(x, m.W.Wk, m.W.Bk),
		Linear(x, m.W.Wv, m.W.Bv)
}

func (m *Model) attnPrefill(x Matrix, cache *KVCache) Matrix {
	q, k, v := m.qkv(x)
	t, d := x.Rows, m.Config.NEmbd
	scale := 1.0 / math.Sqrt(float64(d))
	out := NewMatrix(t, d)
	for i := 0; i < t; i++ {
		scores := make([]float64, t)
		for j := 0; j < t; j++ {
			if j > i {
				scores[j] = -1e30
				continue
			}
			s := 0.0
			for z := 0; z < d; z++ {
				s += q.At(i, z) * k.At(j, z)
			}
			scores[j] = s * scale
		}
		probs := Softmax(scores)
		for z := 0; z < d; z++ {
			s := 0.0
			for j := 0; j < t; j++ {
				s += probs[j] * v.At(j, z)
			}
			out.Set(i, z, s)
		}
	}
	for i := 0; i < t; i++ {
		cache.K = append(cache.K, append([]float64(nil), k.Row(i)...))
		cache.V = append(cache.V, append([]float64(nil), v.Row(i)...))
	}
	return out
}

func (m *Model) attnDecode(x Matrix, cache *KVCache) Matrix {
	q, k, v := m.qkv(x)
	d := m.Config.NEmbd
	cache.K = append(cache.K, append([]float64(nil), k.Row(0)...))
	cache.V = append(cache.V, append([]float64(nil), v.Row(0)...))
	scores := make([]float64, len(cache.K))
	scale := 1.0 / math.Sqrt(float64(d))
	for j := range cache.K {
		s := 0.0
		for z := 0; z < d; z++ {
			s += q.At(0, z) * cache.K[j][z]
		}
		scores[j] = s * scale
	}
	probs := Softmax(scores)
	out := NewMatrix(1, d)
	for z := 0; z < d; z++ {
		s := 0.0
		for j := range cache.V {
			s += probs[j] * cache.V[j][z]
		}
		out.Set(0, z, s)
	}
	return out
}

func (m *Model) block(x Matrix, cache *KVCache, prefill bool) Matrix {
	h := LayerNorm(x, m.W.Ln1G, m.W.Ln1B, 1e-5)
	var a Matrix
	if prefill {
		a = m.attnPrefill(h, cache)
	} else {
		a = m.attnDecode(h, cache)
	}
	y := Linear(a, m.W.Wo, m.W.Bo)
	x = AddRows(x, y)
	h = LayerNorm(x, m.W.Ln2G, m.W.Ln2B, 1e-5)
	h = Relu(Linear(h, m.W.W1, m.W.B1))
	h = Linear(h, m.W.W2, m.W.B2)
	x = AddRows(x, h)
	return LayerNorm(x, m.W.LnfG, m.W.LnfB, 1e-5)
}

func (m *Model) logitsFromHidden(h Matrix) []float64 {
	return Linear(h, m.W.LmHead, m.W.LmB).Row(h.Rows - 1)
}

func (m *Model) Prefill(ids []int, cache *KVCache) []float64 {
	x := Embed(m.W.TokEmb, ids)
	pos := make([]int, len(ids))
	for i := range pos {
		pos[i] = i
	}
	p := Embed(m.W.PosEmb, pos)
	x = AddRows(x, p)
	h := m.block(x, cache, true)
	return m.logitsFromHidden(h)
}

func (m *Model) Decode(token int, pos int, cache *KVCache) []float64 {
	x := NewMatrix(1, m.Config.NEmbd)
	copy(x.Row(0), m.W.TokEmb.Row(token))
	for i := 0; i < m.Config.NEmbd; i++ {
		x.Data[i] += m.W.PosEmb.At(pos, i)
	}
	h := m.block(x, cache, false)
	return m.logitsFromHidden(h)
}

func (m *Model) FullLogits(ids []int) []float64 {
	cache := &KVCache{}
	return m.Prefill(ids, cache)
}

type Sample struct {
	ID   int
	Prob float64
}

func SampleTop(logits []float64, temperature float64, topK int, topP float64, rng *RNG) (int, []Sample) {
	if temperature <= 0 {
		probs := Softmax(logits)
		best := 0
		for i := 1; i < len(probs); i++ {
			if probs[i] > probs[best] {
				best = i
			}
		}
		top := make([]Sample, 0, 5)
		for i, p := range probs {
			top = append(top, Sample{i, p})
		}
		sortSamples(top)
		if len(top) > 5 {
			top = top[:5]
		}
		return best, top
	}
	scaled := make([]float64, len(logits))
	for i, v := range logits {
		scaled[i] = v / temperature
	}
	order := make([]int, len(scaled))
	for i := range order {
		order[i] = i
	}
	for i := 1; i < len(order); i++ {
		for j := i; j > 0 && scaled[order[j]] > scaled[order[j-1]]; j-- {
			order[j], order[j-1] = order[j-1], order[j]
		}
	}
	if topK > 0 && topK < len(order) {
		order = order[:topK]
	}
	probs := Softmax(selectF(scaled, order))
	if topP < 1.0 {
		keep := []int{}
		acc := 0.0
		for i, p := range probs {
			keep = append(keep, order[i])
			acc += p
			if acc >= topP {
				break
			}
		}
		order = keep
		probs = Softmax(selectF(scaled, order))
	}
	r := rng.Float64()
	acc := 0.0
	pick := order[0]
	for i, p := range probs {
		acc += p
		if r <= acc {
			pick = order[i]
			break
		}
	}
	top := make([]Sample, len(order))
	for i, id := range order {
		top[i] = Sample{id, probs[i]}
	}
	sortSamples(top)
	if len(top) > 5 {
		top = top[:5]
	}
	return pick, top
}

func selectF(v []float64, idx []int) []float64 {
	out := make([]float64, len(idx))
	for i, j := range idx {
		out[i] = v[j]
	}
	return out
}

func sortSamples(s []Sample) {
	for i := 1; i < len(s); i++ {
		for j := i; j > 0 && s[j].Prob > s[j-1].Prob; j-- {
			s[j], s[j-1] = s[j-1], s[j]
		}
	}
}

// RNG is splitmix64: tiny, deterministic, and easy to reimplement elsewhere.
type RNG struct{ State uint64 }

func NewRNG(seed uint64) *RNG { return &RNG{State: seed} }

func (r *RNG) Next() uint64 {
	r.State += 0x9E3779B97F4A7C15
	z := r.State
	z = (z ^ (z >> 30)) * 0xBF58476D1CE4E5B9
	z = (z ^ (z >> 27)) * 0x94D049BB133111EB
	return z ^ (z >> 31)
}

func (r *RNG) Float64() float64 {
	return float64(r.Next()>>11) / float64(1<<53)
}

func (r *RNG) Intn(n int) int {
	return int(r.Next() % uint64(n))
}
