module tinyllm

go 1.21
