package main

import (
	"flag"
	"fmt"
	"math"
	"os"
	"path/filepath"
	"strings"
	"time"

	"tinyllm/tiny"
)

func main() {
	weights := flag.String("weights", "../weights/tiny_py.json", "path to weights json")
	prompt := flag.String("prompt", "the cat ", "prompt text")
	n := flag.Int("n", 24, "max new tokens")
	temp := flag.Float64("temp", 0.0, "temperature (0 = greedy)")
	topK := flag.Int("topk", 6, "top-k")
	topP := flag.Float64("topp", 1.0, "top-p")
	seed := flag.Uint64("seed", 7, "rng seed")
	logPath := flag.String("log", "../out/infer_go.txt", "log file")
	flag.Parse()

	mdl, err := tiny.Load(*weights)
	if err != nil {
		panic(err)
	}
	stoi := map[string]int{}
	for i, c := range mdl.Vocab {
		stoi[c] = i
	}
	promptIDs := make([]int, 0, len(*prompt))
	for _, r := range *prompt {
		id, ok := stoi[string(r)]
		if !ok {
			panic(fmt.Sprintf("character %q not in vocab", r))
		}
		promptIDs = append(promptIDs, id)
	}
	if len(promptIDs) >= mdl.Config.BlockSize {
		panic("prompt too long")
	}

	var lines []string
	say := func(s string) {
		fmt.Println(s)
		lines = append(lines, s)
	}
	vocab := mdl.Vocab
	say(fmt.Sprintf("model: %d layer, %d head, d_model=%d, ff=%d, vocab=%d, block=%d",
		mdl.Config.NLayer, mdl.Config.NHead, mdl.Config.NEmbd, mdl.Config.DFF,
		mdl.Config.VocabSize, mdl.Config.BlockSize))
	say(fmt.Sprintf("params: %d", mdl.ParamCount()))
	say(fmt.Sprintf("prompt: %q -> %d tokens %v", *prompt, len(promptIDs), promptIDs))
	say("")

	cache := &tiny.KVCache{}
	t0 := time.Now()
	logits := mdl.Prefill(promptIDs, cache)
	prefillMS := float64(time.Since(t0).Microseconds()) / 1000.0
	rng := tiny.NewRNG(*seed)
	first, top := tiny.SampleTop(logits, *temp, *topK, *topP, rng)
	ids := append(append([]int{}, promptIDs...), first)
	say(fmt.Sprintf("prefill: %d tokens in %.3f ms; first token %q; cache %d tokens, %d bytes (float64)",
		len(promptIDs), prefillMS, vocab[first], cache.SeqLen(), cache.Bytes(8)))
	topStrs := make([]string, 0, 5)
	for _, s := range top {
		topStrs = append(topStrs, fmt.Sprintf("%q:%.4f", vocab[s.ID], s.Prob))
	}
	say("  top-5: " + strings.Join(topStrs, ", "))
	say("")
	say(fmt.Sprintf("%4s %5s %8s %6s %7s  %s", "step", "token", "p(top1)", "cache", "ms", "top-3"))

	var stepTimes []float64
	for step := 0; step < *n; step++ {
		t := time.Now()
		logits = mdl.Decode(ids[len(ids)-1], len(ids)-1, cache)
		nxt, top := tiny.SampleTop(logits, *temp, *topK, *topP, rng)
		ms := float64(time.Since(t).Microseconds()) / 1000.0
		stepTimes = append(stepTimes, ms)
		ids = append(ids, nxt)
		var sb strings.Builder
		for i, s := range top {
			if i >= 3 {
				break
			}
			if i > 0 {
				sb.WriteString(", ")
			}
			sb.WriteString(fmt.Sprintf("%q:%.3f", vocab[s.ID], s.Prob))
		}
		say(fmt.Sprintf("%4d %5q %8.4f %6d %7.3f  %s", step, vocab[nxt], top[0].Prob, cache.SeqLen(), ms, sb.String()))
		if vocab[nxt] == "." && step > 2 {
			break
		}
	}
	var out strings.Builder
	for _, id := range ids {
		out.WriteString(vocab[id])
	}
	say("")
	say(fmt.Sprintf("output: %q", out.String()))
	sum := 0.0
	for _, v := range stepTimes {
		sum += v
	}
	say(fmt.Sprintf("decode: %d steps, mean %.3f ms/token, total %.3f ms",
		len(stepTimes), sum/float64(len(stepTimes)), sum))
	say(fmt.Sprintf("KV cache final: %d tokens, %d bytes (%.1f KiB, float64)",
		cache.SeqLen(), cache.Bytes(8), float64(cache.Bytes(8))/1024.0))

	say("")
	say("verification: compare cached decode with full recomputation")
	cache2 := &tiny.KVCache{}
	mdl.Prefill(promptIDs, cache2)
	maxDiff := 0.0
	check := len(stepTimes)
	if check > 12 {
		check = 12
	}
	for step := 0; step < check; step++ {
		cached := mdl.Decode(ids[len(promptIDs)+step], len(promptIDs)+step, cache2)
		full := mdl.FullLogits(ids[:len(promptIDs)+step+1])
		diff := 0.0
		for i := range cached {
			d := math.Abs(cached[i] - full[i])
			if d > diff {
				diff = d
			}
		}
		if diff > maxDiff {
			maxDiff = diff
		}
		say(fmt.Sprintf("  pos %2d: max|cached-full| = %.3e", len(promptIDs)+step, diff))
	}
	say(fmt.Sprintf("  max diff over checked positions = %.3e", maxDiff))

	runCached := func() float64 {
		c := &tiny.KVCache{}
		mdl.Prefill(promptIDs, c)
		start := time.Now()
		for step := 0; step < 24; step++ {
			_ = mdl.Decode(ids[step%len(ids)], len(promptIDs)+step, c)
		}
		return float64(time.Since(start).Microseconds()) / 1000.0
	}
	runFull := func() float64 {
		seq := append([]int{}, promptIDs...)
		start := time.Now()
		for step := 0; step < 24; step++ {
			seq = append(seq, ids[step%len(ids)])
			_ = mdl.FullLogits(seq)
		}
		return float64(time.Since(start).Microseconds()) / 1000.0
	}
	tc, tf := runCached(), runFull()
	say("")
	say(fmt.Sprintf("timing (24 decode steps): cached=%.2f ms, full-recompute=%.2f ms, speedup=%.2fx", tc, tf, tf/tc))

	if err := os.MkdirAll(filepath.Dir(*logPath), 0o755); err != nil {
		panic(err)
	}
	if err := os.WriteFile(*logPath, []byte(strings.Join(lines, "\n")+"\n"), 0o644); err != nil {
		panic(err)
	}
	say("log written to " + *logPath)
}
