package main

import "fmt"

func lossAt(w, b, x, y float64) (float64, float64) {
	pred := w*x + b
	d := pred - y
	return d * d, pred
}

func main() {
	w, b, x, y := 0.5, 0.0, 2.0, 3.0
	lr := 0.05
	fmt.Println("=== one manual step ===")
	loss, pred := lossAt(w, b, x, y)
	dlDpred := 2 * (pred - y)
	dlDw := dlDpred * x
	dlDb := dlDpred
	fmt.Printf("forward: pred = %v*%v + %v = %v\n", w, x, b, pred)
	fmt.Printf("loss   = (pred - y)^2 = (%v - %v)^2 = %v\n", pred, y, loss)
	fmt.Printf("dL/dpred = 2*(pred-y) = %v\n", dlDpred)
	fmt.Printf("dL/dw = dL/dpred * x = %v\n", dlDw)
	fmt.Printf("dL/db = dL/dpred * 1 = %v\n", dlDb)
	w1, b1 := w-lr*dlDw, b-lr*dlDb
	loss1, pred1 := lossAt(w1, b1, x, y)
	fmt.Printf("update: w=%v, b=%v\n", w1, b1)
	fmt.Printf("new pred=%v, new loss=%v\n", pred1, loss1)

	fmt.Println("\n=== 10 steps of gradient descent ===")
	fmt.Printf("%4s %10s %10s %10s %12s\n", "step", "w", "b", "pred", "loss")
	w, b = 0.5, 0.0
	for step := 0; step <= 10; step++ {
		loss, pred := lossAt(w, b, x, y)
		fmt.Printf("%4d %10.6f %10.6f %10.6f %12.8f\n", step, w, b, pred, loss)
		gW := 2 * (pred - y) * x
		gB := 2 * (pred - y)
		w -= lr * gW
		b -= lr * gB
	}

	fmt.Println("\n=== numeric gradient check at w=0.5, b=0 ===")
	eps := 1e-6
	l1, _ := lossAt(0.5+eps, 0.0, x, y)
	l2, _ := lossAt(0.5-eps, 0.0, x, y)
	fmt.Printf("w: numeric=%.8f\n", (l1-l2)/(2*eps))
	l1, _ = lossAt(0.5, eps, x, y)
	l2, _ = lossAt(0.5, -eps, x, y)
	fmt.Printf("b: numeric=%.8f\n", (l1-l2)/(2*eps))
}
