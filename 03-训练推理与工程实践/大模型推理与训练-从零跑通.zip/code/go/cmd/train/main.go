package main

import (
	"encoding/json"
	"flag"
	"fmt"
	"math"
	"os"
	"path/filepath"
	"sort"
	"strings"
	"time"

	"tinyllm/tiny"
)

func loadCorpus(path string) (string, []string, map[string]int) {
	b, err := os.ReadFile(path)
	if err != nil {
		panic(err)
	}
	text := strings.ReplaceAll(string(b), "\n", " ")
	set := map[rune]bool{}
	for _, r := range text {
		set[r] = true
	}
	vocab := make([]string, 0, len(set))
	for r := range set {
		vocab = append(vocab, string(r))
	}
	sort.Strings(vocab)
	stoi := map[string]int{}
	for i, c := range vocab {
		stoi[c] = i
	}
	return text, vocab, stoi
}

func encode(text string, stoi map[string]int) []int {
	out := make([]int, 0, len(text))
	for _, r := range text {
		out = append(out, stoi[string(r)])
	}
	return out
}

func decode(ids []int, vocab []string) string {
	var b strings.Builder
	for _, id := range ids {
		b.WriteString(vocab[id])
	}
	return b.String()
}

func sampleBatch(ids []int, block, batch int, rng *tiny.RNG) ([][]int, [][]int) {
	xs := make([][]int, batch)
	ys := make([][]int, batch)
	for b := 0; b < batch; b++ {
		i := rng.Intn(len(ids) - block - 1)
		xs[b] = append([]int{}, ids[i:i+block]...)
		ys[b] = append([]int{}, ids[i+1:i+block+1]...)
	}
	return xs, ys
}

func lrAt(step, total int, peak float64, warmup int) float64 {
	if step < warmup {
		return peak * float64(step+1) / float64(warmup)
	}
	p := float64(step-warmup) / float64(max(1, total-warmup))
	return 0.1*peak + 0.9*peak*0.5*(1+math.Cos(math.Pi*p))
}

func max(a, b int) int {
	if a > b {
		return a
	}
	return b
}

func main() {
	corpus := flag.String("corpus", "../data/corpus.txt", "corpus path")
	steps := flag.Int("steps", 800, "training steps")
	batch := flag.Int("batch", 4, "batch size")
	block := flag.Int("block", 32, "sequence length")
	lr := flag.Float64("lr", 3e-3, "peak learning rate")
	seed := flag.Uint64("seed", 42, "random seed")
	out := flag.String("out", "../weights/tiny_go.json", "weights output")
	logPath := flag.String("log", "../out/train_go.txt", "log output")
	flag.Parse()

	text, vocab, stoi := loadCorpus(*corpus)
	ids := encode(text, stoi)
	split := int(float64(len(ids)) * 0.85)
	trainIDs, valIDs := ids[:split], ids[split:]
	cfg := tiny.Config{VocabSize: len(vocab), BlockSize: *block, NLayer: 1, NHead: 1, NEmbd: 24, DFF: 48}
	mdl := &tiny.Model{Config: cfg, Vocab: vocab}
	params := tiny.InitWeights(cfg, *seed)
	mdl.W = *params
	grads := tiny.InitWeights(cfg, 0)
	tiny.ZeroGrads(grads)
	mom := tiny.InitWeights(cfg, 0)
	vel := tiny.InitWeights(cfg, 0)
	tiny.ZeroGrads(mom)
	tiny.ZeroGrads(vel)
	rng := tiny.NewRNG(*seed + 1)
	fmt.Printf("vocab=%d params=%d block=%d train_chars=%d val_chars=%d\n",
		len(vocab), mdl.ParamCount(), *block, len(trainIDs), len(valIDs))
	fmt.Printf("%5s %8s %8s %8s %7s\n", "step", "lr", "loss", "gnorm", "ms")

	start := time.Now()
	var lines []string
	var loss float64
	for step := 0; step < *steps; step++ {
		currentLR := lrAt(step, *steps, *lr, 20)
		xs, ys := sampleBatch(trainIDs, cfg.BlockSize, *batch, rng)
		tiny.ZeroGrads(grads)
		loss = 0
		for b := range xs {
			loss += mdl.TrainStep(params, grads, xs[b], ys[b])
		}
		loss /= float64(len(xs))
		grads.Scale(1.0 / float64(len(xs)))
		gnorm := grads.GlobalNorm()
		if gnorm > 1.0 {
			grads.Scale(1.0 / (gnorm + 1e-12))
		}
		mdl.AdamStep(params, grads, mom, vel, currentLR, step+1)
		if step%20 == 0 || step == *steps-1 {
			line := fmt.Sprintf("%5d %8.5f %8.4f %8.3f %7.1f",
				step, currentLR, loss, gnorm, float64(time.Since(start).Milliseconds()))
			fmt.Println(line)
			lines = append(lines, line)
		}
	}

	// validation
	vrng := tiny.NewRNG(7)
	valLoss := 0.0
	for i := 0; i < 5; i++ {
		xs, ys := sampleBatch(valIDs, cfg.BlockSize, 4, vrng)
		for b := range xs {
			valLoss += mdl.Loss(params, xs[b], ys[b])
		}
	}
	valLoss /= 20.0

	period := stoi["."]
	prompt := encode("the cat ", stoi)
	gen := mdl.Generate(params, prompt, 40, 0.7, 6, period, 3, tiny.NewRNG(123))
	sample := decode(gen, vocab)
	summary := map[string]any{
		"vocab_size": len(vocab), "params": mdl.ParamCount(),
		"steps": *steps, "batch": *batch, "block": *block,
		"final_loss": loss, "val_loss": valLoss,
		"sample": sample, "elapsed_s": time.Since(start).Seconds(),
	}
	if err := mdl.Save(*out, vocab, params); err != nil {
		panic(err)
	}
	if err := os.MkdirAll(filepath.Dir(*logPath), 0o755); err != nil {
		panic(err)
	}
	b, _ := json.MarshalIndent(summary, "", "  ")
	textOut := strings.Join(lines, "\n") + "\n" + string(b) + "\n"
	if err := os.WriteFile(*logPath, []byte(textOut), 0o644); err != nil {
		panic(err)
	}
	fmt.Println("sample:", sample)
	fmt.Println("saved", *out)
	fmt.Println(string(b))
}
