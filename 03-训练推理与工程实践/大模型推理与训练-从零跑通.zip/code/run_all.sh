#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"
mkdir -p out weights
export GOCACHE="${GOCACHE:-$ROOT/.gocache}"

echo "== Python neuron =="
python3 py/neuron.py | tee out/neuron_python.txt

echo "== Go neuron =="
(cd go && go run ./cmd/neuron) | tee out/neuron_go.txt

echo "== BPE =="
python3 py/bpe.py | tee out/bpe.txt

echo "== Python train (600 steps) =="
python3 py/train.py --steps 600 --batch 4 \
  --out weights/tiny_py.json --log out/train_python.txt | tee out/train_python_console.txt

echo "== Go train (1200 steps) =="
(cd go && go run ./cmd/train -steps 1200 \
  -out ../weights/tiny_go.json -log ../out/train_go.txt) | tee out/train_go_console.txt

echo "== Python inference (greedy) =="
python3 py/infer.py --weights weights/tiny_py.json --temperature 0 \
  --log out/infer_python_greedy.txt | tee out/infer_python_console.txt

echo "== Go inference (greedy, Python weights) =="
(cd go && go run ./cmd/infer -weights ../weights/tiny_py.json -temp 0 \
  -log ../out/infer_go.txt) | tee out/infer_go_console.txt

echo "== SFT/DPO, schedule, quant =="
python3 py/sft_dpo.py | tee out/sft_dpo.txt
python3 py/schedule.py | tee out/schedule.txt
python3 py/quant.py | tee out/quant.txt

echo
echo "done. logs in $ROOT/out/"
