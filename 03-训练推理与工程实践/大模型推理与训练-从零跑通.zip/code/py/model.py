"""A one-layer, one-head, decoder-only Transformer written with our autograd."""
from __future__ import annotations

import json
import math
import random
from dataclasses import dataclass, asdict
from typing import Dict, List, Sequence

from autograd import (
    Tensor, add, mul, scale, matmul, transpose, relu, layernorm,
    softmax_rows, masked_fill, embedding, cross_entropy, causal_mask,
)


@dataclass
class Config:
    vocab_size: int
    block_size: int
    n_layer: int = 1
    n_head: int = 1
    n_embd: int = 24
    d_ff: int = 48
    dropout: float = 0.0


def init_params(cfg: Config, seed: int = 42) -> Dict[str, Tensor]:
    rng = random.Random(seed)
    def mat(rows: int, cols: int, std: float) -> Tensor:
        return Tensor([rng.gauss(0.0, std) for _ in range(rows * cols)],
                      (rows, cols), requires_grad=True)
    def vec(n: int, value: float = 0.0) -> Tensor:
        return Tensor([value] * n, (n,), requires_grad=True)
    std = 1.0 / math.sqrt(cfg.n_embd)
    p: Dict[str, Tensor] = {
        "tok_emb": mat(cfg.vocab_size, cfg.n_embd, 0.02),
        "pos_emb": mat(cfg.block_size, cfg.n_embd, 0.01),
        "ln1_g": vec(cfg.n_embd, 1.0), "ln1_b": vec(cfg.n_embd, 0.0),
        "wq": mat(cfg.n_embd, cfg.n_embd, std), "bq": vec(cfg.n_embd, 0.0),
        "wk": mat(cfg.n_embd, cfg.n_embd, std), "bk": vec(cfg.n_embd, 0.0),
        "wv": mat(cfg.n_embd, cfg.n_embd, std), "bv": vec(cfg.n_embd, 0.0),
        "wo": mat(cfg.n_embd, cfg.n_embd, std), "bo": vec(cfg.n_embd, 0.0),
        "ln2_g": vec(cfg.n_embd, 1.0), "ln2_b": vec(cfg.n_embd, 0.0),
        "w1": mat(cfg.n_embd, cfg.d_ff, std), "b1": vec(cfg.d_ff, 0.0),
        "w2": mat(cfg.d_ff, cfg.n_embd, std), "b2": vec(cfg.n_embd, 0.0),
        "lnf_g": vec(cfg.n_embd, 1.0), "lnf_b": vec(cfg.n_embd, 0.0),
        "lm_head": mat(cfg.n_embd, cfg.vocab_size, std), "lm_b": vec(cfg.vocab_size, 0.0),
    }
    return p


def param_count(cfg: Config) -> int:
    p = init_params(cfg)
    return sum(len(t.data) for t in p.values())


def forward(params: Dict[str, Tensor], tokens: Sequence[int], cfg: Config) -> Tensor:
    t = len(tokens)
    assert t <= cfg.block_size
    x = add(embedding(params["tok_emb"], list(tokens)),
            embedding(params["pos_emb"], list(range(t))))
    # --- attention block ---
    h = layernorm(x, params["ln1_g"], params["ln1_b"])
    q = add(matmul(h, params["wq"]), params["bq"])
    k = add(matmul(h, params["wk"]), params["bk"])
    v = add(matmul(h, params["wv"]), params["bv"])
    scores = scale(matmul(q, transpose(k)), 1.0 / math.sqrt(cfg.n_embd))
    scores = masked_fill(scores, causal_mask(t), -1e9)
    attn = softmax_rows(scores)
    y = matmul(attn, v)
    y = add(matmul(y, params["wo"]), params["bo"])
    x = add(x, y)
    # --- MLP block ---
    h = layernorm(x, params["ln2_g"], params["ln2_b"])
    h = add(matmul(h, params["w1"]), params["b1"])
    h = relu(h)
    h = add(matmul(h, params["w2"]), params["b2"])
    x = add(x, h)
    x = layernorm(x, params["lnf_g"], params["lnf_b"])
    logits = add(matmul(x, params["lm_head"]), params["lm_b"])
    return logits


def loss_fn(params: Dict[str, Tensor], x: Sequence[int], y: Sequence[int],
            cfg: Config) -> Tensor:
    return cross_entropy(forward(params, x, cfg), y)


def save_weights(path: str, cfg: Config, vocab: List[str],
                 params: Dict[str, Tensor]) -> None:
    obj = {
        "config": asdict(cfg),
        "vocab": vocab,
        "weights": {name: {"shape": list(t.shape), "data": t.data}
                    for name, t in params.items()},
    }
    with open(path, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, separators=(",", ":"))


def load_weights(path: str) -> tuple[Config, List[str], Dict[str, Tensor]]:
    with open(path, encoding="utf-8") as f:
        obj = json.load(f)
    cfg = Config(**obj["config"])
    vocab = obj["vocab"]
    params = {name: Tensor(v["data"], tuple(v["shape"]), requires_grad=True)
              for name, v in obj["weights"].items()}
    return cfg, vocab, params
