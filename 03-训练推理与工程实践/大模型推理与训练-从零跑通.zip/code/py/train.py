"""Train the tiny Transformer on a character-level corpus.

Everything is pure Python: no numpy, no torch.  The point is to make every
number in the training loop visible.
"""
from __future__ import annotations

import argparse
import json
import math
import os
import random
import sys
import time
from typing import Dict, List, Sequence

sys.path.insert(0, os.path.dirname(__file__))
from autograd import Tensor, add, scale, backward
from model import Config, init_params, forward, loss_fn, param_count, save_weights


def load_corpus(path: str) -> tuple[str, List[str]]:
    text = open(path, encoding="utf-8").read().replace("\n", " ")
    vocab = sorted(set(text))
    return text, vocab


def encode(text: str, vocab: List[str]) -> List[int]:
    stoi = {c: i for i, c in enumerate(vocab)}
    return [stoi[c] for c in text]


def decode(ids: Sequence[int], vocab: List[str]) -> str:
    return "".join(vocab[i] for i in ids)


def sample_batch(ids: List[int], block: int, batch: int,
                 rng: random.Random) -> tuple[List[List[int]], List[List[int]]]:
    xs, ys = [], []
    for _ in range(batch):
        i = rng.randrange(0, len(ids) - block - 1)
        xs.append(ids[i:i + block])
        ys.append(ids[i + 1:i + block + 1])
    return xs, ys


def evaluate(params, ids: List[int], cfg: Config, block: int,
             batches: int = 10, seed: int = 7) -> float:
    rng = random.Random(seed)
    total = 0.0
    for _ in range(batches):
        xs, ys = sample_batch(ids, block, 4, rng)
        for x, y in zip(xs, ys):
            total += loss_fn(params, x, y, cfg).item()
    return total / (batches * 4)


def global_norm(params: Dict[str, Tensor]) -> float:
    return math.sqrt(sum(g * g for t in params.values() for g in t.grad))


def clip_grads(params: Dict[str, Tensor], max_norm: float) -> float:
    norm = global_norm(params)
    if norm > max_norm:
        s = max_norm / (norm + 1e-12)
        for t in params.values():
            for i in range(len(t.grad)):
                t.grad[i] *= s
    return norm


def adam_step(params: Dict[str, Tensor], state: Dict[str, list],
              step: int, lr: float, beta1: float = 0.9, beta2: float = 0.95,
              eps: float = 1e-8, weight_decay: float = 0.01) -> None:
    for name, t in params.items():
        m, v = state[name]
        for i, g in enumerate(t.grad):
            m[i] = beta1 * m[i] + (1 - beta1) * g
            v[i] = beta2 * v[i] + (1 - beta2) * g * g
        bc1 = 1 - beta1 ** step
        bc2 = 1 - beta2 ** step
        for i in range(len(t.data)):
            mh = m[i] / bc1
            vh = v[i] / bc2
            t.data[i] -= lr * (mh / (math.sqrt(vh) + eps) + weight_decay * t.data[i])
        for i in range(len(t.grad)):
            t.grad[i] = 0.0


def lr_at(step: int, total: int, peak: float, warmup: int = 20) -> float:
    if step < warmup:
        return peak * (step + 1) / warmup
    p = (step - warmup) / max(1, total - warmup)
    return 0.1 * peak + 0.9 * peak * 0.5 * (1 + math.cos(math.pi * p))


def generate(params, vocab: List[str], prompt: str, n: int, cfg: Config,
             temperature: float = 0.8, top_k: int = 8,
             rng: random.Random | None = None) -> str:
    rng = rng or random.Random(123)
    ids = encode(prompt, vocab)
    for _ in range(n):
        ctx = ids[-cfg.block_size:]
        logits = forward(params, ctx, cfg)
        row = logits.data[-cfg.vocab_size:]
        # temperature
        scaled = [z / max(temperature, 1e-6) for z in row]
        # top-k
        order = sorted(range(len(scaled)), key=lambda i: scaled[i], reverse=True)[:top_k]
        m = max(scaled[i] for i in order)
        ex = {i: math.exp(scaled[i] - m) for i in order}
        s = sum(ex.values())
        r = rng.random() * s
        acc = 0.0
        pick = order[0]
        for i in order:
            acc += ex[i]
            if r <= acc:
                pick = i
                break
        ids.append(pick)
        if vocab[pick] == "." and len(ids) > len(prompt) + 2:
            break
    return decode(ids, vocab)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--corpus", default=os.path.join(os.path.dirname(__file__), "..", "data", "corpus.txt"))
    ap.add_argument("--steps", type=int, default=400)
    ap.add_argument("--batch", type=int, default=4)
    ap.add_argument("--block", type=int, default=32)
    ap.add_argument("--lr", type=float, default=3e-3)
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--out", default=os.path.join(os.path.dirname(__file__), "..", "weights", "tiny_py.json"))
    ap.add_argument("--log", default=os.path.join(os.path.dirname(__file__), "..", "out", "train_python.txt"))
    args = ap.parse_args()

    text, vocab = load_corpus(args.corpus)
    ids = encode(text, vocab)
    split = int(len(ids) * 0.85)
    train_ids, val_ids = ids[:split], ids[split:]
    cfg = Config(vocab_size=len(vocab), block_size=args.block)
    params = init_params(cfg, seed=args.seed)
    state = {name: ([0.0] * len(t.data), [0.0] * len(t.data))
             for name, t in params.items()}
    rng = random.Random(args.seed + 1)
    print(f"vocab={len(vocab)} params={param_count(cfg)} block={cfg.block_size} "
          f"train_chars={len(train_ids)} val_chars={len(val_ids)}")
    print(f"{'step':>5} {'lr':>8} {'loss':>8} {'gnorm':>8} {'ms':>7}")
    t0 = time.time()
    lines = []
    for step in range(args.steps):
        lr = lr_at(step, args.steps, args.lr)
        xs, ys = sample_batch(train_ids, cfg.block_size, args.batch, rng)
        total = None
        for x, y in zip(xs, ys):
            l = loss_fn(params, x, y, cfg)
            total = l if total is None else add(total, l)
        total = scale(total, 1.0 / len(xs))
        backward(total)
        gnorm = clip_grads(params, 1.0)
        adam_step(params, state, step + 1, lr)
        if step % 20 == 0 or step == args.steps - 1:
            val = evaluate(params, val_ids, cfg, cfg.block_size, batches=5)
            line = f"{step:5d} {lr:8.5f} {total.item():8.4f} {gnorm:8.3f} {(time.time()-t0)*1000:7.1f}"
            print(line, flush=True)
            lines.append(line + f"  val={val:.4f}")
    save_weights(args.out, cfg, vocab, params)
    sample = generate(params, vocab, "the cat ", 40, cfg, temperature=0.7, top_k=6)
    summary = {
        "vocab_size": len(vocab), "params": param_count(cfg),
        "steps": args.steps, "batch": args.batch, "block": args.block,
        "final_loss": total.item(), "val_loss": evaluate(params, val_ids, cfg, cfg.block_size),
        "sample": sample, "elapsed_s": time.time() - t0,
    }
    with open(args.log, "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")
        f.write(json.dumps(summary, ensure_ascii=False, indent=2) + "\n")
    print("sample:", sample)
    print("saved", args.out)
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
