"""A tiny BPE trainer: learn merges from the same corpus used by the model.

The point is to make 'token' concrete.  The model demo uses a character-level
tokenizer for clarity; this script shows what a real tokenizer does instead.
"""
from collections import Counter
import os


def train_bpe(text: str, n_merges: int = 24) -> tuple[list[tuple[str, str]], list[str]]:
    words = Counter(text.split())
    # each word is a tuple of symbols, with its corpus frequency
    corpus = [(tuple(w), c) for w, c in words.items()]
    vocab = sorted({ch for w in words for ch in w})
    merges: list[tuple[str, str]] = []
    for _ in range(n_merges):
        pairs: Counter[tuple[str, str]] = Counter()
        for symbols, freq in corpus:
            for a, b in zip(symbols, symbols[1:]):
                pairs[(a, b)] += freq
        if not pairs:
            break
        best, count = pairs.most_common(1)[0]
        merges.append(best)
        merged = best[0] + best[1]
        vocab.append(merged)
        new_corpus = []
        for symbols, freq in corpus:
            out, i = [], 0
            while i < len(symbols):
                if i + 1 < len(symbols) and (symbols[i], symbols[i + 1]) == best:
                    out.append(merged)
                    i += 2
                else:
                    out.append(symbols[i])
                    i += 1
            new_corpus.append((tuple(out), freq))
        corpus = new_corpus
        print(f"merge {len(merges):2d}: {best[0]!r} + {best[1]!r} -> {merged!r}  (freq {count})")
    return merges, vocab


def tokenize(word: str, merges: list[tuple[str, str]]) -> list[str]:
    symbols = list(word)
    for a, b in merges:
        out, i = [], 0
        while i < len(symbols):
            if i + 1 < len(symbols) and symbols[i] == a and symbols[i + 1] == b:
                out.append(a + b)
                i += 2
            else:
                out.append(symbols[i])
                i += 1
        symbols = out
    return symbols


def main() -> None:
    path = os.path.join(os.path.dirname(__file__), "..", "data", "corpus.txt")
    text = open(path, encoding="utf-8").read().replace("\n", " ")
    print("=== BPE merges learned from the toy corpus ===")
    merges, vocab = train_bpe(text, 24)
    print(f"\nvocab size after merges: {len(vocab)}")
    print("\n=== how the learned tokenizer cuts words ===")
    for w in ["the", "cat", "sat", "dog", "log", "mat", "ran"]:
        pieces = tokenize(w, merges)
        print(f"{w:5s} -> {pieces}  ({len(w)} chars -> {len(pieces)} tokens)")
    sentence = "the cat sat on the mat ."
    pieces = tokenize(sentence, merges)
    print(f"\nsentence: {sentence!r}")
    print(f"chars={len(sentence)}, bpe tokens={len(pieces)}")
    print("pieces:", pieces)


if __name__ == "__main__":
    main()
