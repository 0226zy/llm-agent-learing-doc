"""Static batching vs continuous batching, simulated request by request."""
import math


def static_batches(lengths, slots):
    batches = [lengths[i:i + slots] for i in range(0, len(lengths), slots)]
    steps = sum(max(b) for b in batches)
    slot_steps = steps * slots
    useful = sum(lengths)
    return steps, slot_steps, useful, len(batches)


def continuous(lengths, slots):
    queue = list(lengths)
    active = []  # remaining tokens
    steps = useful = 0
    timeline = []
    while queue or active:
        while len(active) < slots and queue:
            active.append(queue.pop(0))
        if not active:
            break
        steps += 1
        useful += len(active)
        done = 0
        for i in range(len(active)):
            active[i] -= 1
        new_active = [r for r in active if r > 0]
        done = len(active) - len(new_active)
        active = new_active
        if steps <= 8 or done:
            timeline.append((steps, len(active), done, len(queue)))
    return steps, steps * slots, useful, timeline


def main():
    lengths = [100] + [10] * 39
    slots = 4
    s_steps, s_slots, s_useful, s_batches = static_batches(lengths, slots)
    c_steps, c_slots, c_useful, timeline = continuous(lengths, slots)
    print(f"requests={len(lengths)} (one 100-token, 39 ten-token), slots={slots}")
    print(f"static:     batches={s_batches}, steps={s_steps}, slot-steps={s_slots}, "
          f"useful={s_useful}, utilization={s_useful/s_slots:.1%}")
    print(f"continuous: steps={c_steps}, slot-steps={c_slots}, useful={c_useful}, "
          f"utilization={c_useful/c_slots:.1%}")
    print("\ncontinuous timeline (step, active, just-finished, queued):")
    for row in timeline[:15]:
        print("  step %3d: active=%d finished=%d queued=%d" % row)
    print("\nThe long request pins one slot for 100 steps; the other three slots")
    print("are refilled as soon as a short request finishes.  Static batching")
    print("waits for the whole batch, so those three slots idle for 90 steps.")


if __name__ == "__main__":
    main()
