"""A deliberately small reverse-mode autodiff engine.

Only the operations needed by the tiny Transformer are implemented, and every
backward rule is written out explicitly.  The goal is readability, not speed.
"""
from __future__ import annotations

import math
from typing import Iterable, Sequence


class Tensor:
    __slots__ = ("data", "shape", "grad", "requires_grad", "_backward", "_prev")

    def __init__(self, data: Iterable[float], shape: Sequence[int] | None = None,
                 requires_grad: bool = False, _children: tuple = ()) -> None:
        self.data = [float(x) for x in data]
        if shape is None:
            shape = (len(self.data),)
        self.shape = tuple(int(x) for x in shape)
        n = 1
        for d in self.shape:
            n *= d
        if n != len(self.data):
            raise ValueError(f"shape {self.shape} does not match {len(self.data)} values")
        self.requires_grad = requires_grad
        self.grad = [0.0] * len(self.data) if requires_grad else None
        self._backward = lambda: None
        self._prev = _children

    # ---------- helpers ----------
    @property
    def ndim(self) -> int:
        return len(self.shape)

    def item(self) -> float:
        if len(self.data) != 1:
            raise ValueError("item() on a non-scalar")
        return self.data[0]

    def zero_grad(self) -> None:
        if self.grad is not None:
            for i in range(len(self.grad)):
                self.grad[i] = 0.0

    def __repr__(self) -> str:
        return f"Tensor(shape={self.shape}, data={self.data[:4]}...)"


def _make(data: list[float], shape: Sequence[int], children: tuple,
          requires_grad: bool = False) -> Tensor:
    out = Tensor(data, shape, requires_grad=requires_grad, _children=children)
    return out


def _unbroadcast(grad: list[float], grad_shape: tuple[int, ...],
                 target_shape: tuple[int, ...]) -> list[float]:
    """Sum a gradient back down to target_shape (only 1-D bias / scalar cases)."""
    if grad_shape == target_shape:
        return grad
    if len(target_shape) == 1 and len(grad_shape) == 2:
        rows, cols = grad_shape
        assert target_shape[0] == cols, (grad_shape, target_shape)
        out = [0.0] * cols
        for r in range(rows):
            base = r * cols
            for c in range(cols):
                out[c] += grad[base + c]
        return out
    if len(target_shape) == 1 and len(grad_shape) == 1:
        return grad
    if target_shape == (1,) and len(grad_shape) >= 1:
        return [sum(grad)]
    raise ValueError(f"cannot unbroadcast {grad_shape} -> {target_shape}")


# ---------------------------------------------------------------------------
# elementwise ops
# ---------------------------------------------------------------------------
def add(a: Tensor, b: Tensor) -> Tensor:
    if a.shape == b.shape:
        out = _make([x + y for x, y in zip(a.data, b.data)], a.shape, (a, b),
                    a.requires_grad or b.requires_grad)
        def backward() -> None:
            if a.requires_grad:
                for i, g in enumerate(out.grad):
                    a.grad[i] += g
            if b.requires_grad:
                for i, g in enumerate(out.grad):
                    b.grad[i] += g
        out._backward = backward
        return out
    # broadcasting: [T,D] + [D]
    if len(a.shape) == 2 and len(b.shape) == 1 and a.shape[1] == b.shape[0]:
        rows, cols = a.shape
        out = _make([a.data[r * cols + c] + b.data[c]
                     for r in range(rows) for c in range(cols)], a.shape, (a, b),
                    a.requires_grad or b.requires_grad)
        def backward() -> None:
            if a.requires_grad:
                for i, g in enumerate(out.grad):
                    a.grad[i] += g
            if b.requires_grad:
                for r in range(rows):
                    base = r * cols
                    for c in range(cols):
                        b.grad[c] += out.grad[base + c]
        out._backward = backward
        return out
    if len(a.shape) == 1 and len(b.shape) == 2 and b.shape[1] == a.shape[0]:
        return add(b, a)
    raise ValueError(f"add shapes {a.shape} and {b.shape}")


def mul(a: Tensor, b: Tensor) -> Tensor:
    if a.shape == b.shape:
        out = _make([x * y for x, y in zip(a.data, b.data)], a.shape, (a, b),
                    a.requires_grad or b.requires_grad)
        def backward() -> None:
            if a.requires_grad:
                for i, g in enumerate(out.grad):
                    a.grad[i] += g * b.data[i]
            if b.requires_grad:
                for i, g in enumerate(out.grad):
                    b.grad[i] += g * a.data[i]
        out._backward = backward
        return out
    if len(a.shape) == 2 and len(b.shape) == 1 and a.shape[1] == b.shape[0]:
        rows, cols = a.shape
        out = _make([a.data[r * cols + c] * b.data[c]
                     for r in range(rows) for c in range(cols)], a.shape, (a, b),
                    a.requires_grad or b.requires_grad)
        def backward() -> None:
            if a.requires_grad:
                for i, g in enumerate(out.grad):
                    a.grad[i] += g * b.data[i % cols]
            if b.requires_grad:
                for r in range(rows):
                    base = r * cols
                    for c in range(cols):
                        b.grad[c] += out.grad[base + c] * a.data[base + c]
        out._backward = backward
        return out
    raise ValueError(f"mul shapes {a.shape} and {b.shape}")


def scale(a: Tensor, s: float) -> Tensor:
    out = _make([x * s for x in a.data], a.shape, (a,), a.requires_grad)
    def backward() -> None:
        if a.requires_grad:
            for i, g in enumerate(out.grad):
                a.grad[i] += g * s
    out._backward = backward
    return out


def relu(a: Tensor) -> Tensor:
    out = _make([x if x > 0 else 0.0 for x in a.data], a.shape, (a,), a.requires_grad)
    def backward() -> None:
        if a.requires_grad:
            for i, g in enumerate(out.grad):
                a.grad[i] += g if a.data[i] > 0 else 0.0
    out._backward = backward
    return out


def masked_fill(a: Tensor, mask: Sequence[bool], value: float = -1e9) -> Tensor:
    assert len(mask) == len(a.data)
    out = _make([value if mask[i] else a.data[i] for i in range(len(a.data))],
                a.shape, (a,), a.requires_grad)
    def backward() -> None:
        if a.requires_grad:
            for i, g in enumerate(out.grad):
                if not mask[i]:
                    a.grad[i] += g
    out._backward = backward
    return out


def transpose(a: Tensor) -> Tensor:
    assert len(a.shape) == 2
    r, c = a.shape
    data = [a.data[i * c + j] for j in range(c) for i in range(r)]
    out = _make(data, (c, r), (a,), a.requires_grad)
    def backward() -> None:
        if a.requires_grad:
            for i in range(r):
                for j in range(c):
                    a.grad[i * c + j] += out.grad[j * r + i]
    out._backward = backward
    return out


# ---------------------------------------------------------------------------
# matrix / normalization / loss
# ---------------------------------------------------------------------------
def matmul(a: Tensor, b: Tensor) -> Tensor:
    assert len(a.shape) == 2 and len(b.shape) == 2
    n, m = a.shape
    m2, p = b.shape
    assert m == m2, (a.shape, b.shape)
    data = [0.0] * (n * p)
    for i in range(n):
        for k in range(m):
            av = a.data[i * m + k]
            if av == 0.0:
                continue
            for j in range(p):
                data[i * p + j] += av * b.data[k * p + j]
    out = _make(data, (n, p), (a, b), a.requires_grad or b.requires_grad)
    def backward() -> None:
        if a.requires_grad:
            for i in range(n):
                for k in range(m):
                    s = 0.0
                    for j in range(p):
                        s += out.grad[i * p + j] * b.data[k * p + j]
                    a.grad[i * m + k] += s
        if b.requires_grad:
            for k in range(m):
                for j in range(p):
                    s = 0.0
                    for i in range(n):
                        s += a.data[i * m + k] * out.grad[i * p + j]
                    b.grad[k * p + j] += s
    out._backward = backward
    return out


def layernorm(x: Tensor, g: Tensor, b: Tensor, eps: float = 1e-5) -> Tensor:
    assert len(x.shape) == 2 and x.shape[1] == g.shape[0] == b.shape[0]
    rows, cols = x.shape
    out_data = [0.0] * (rows * cols)
    xhat = [0.0] * (rows * cols)
    inv_std = [0.0] * rows
    for r in range(rows):
        base = r * cols
        mean = sum(x.data[base:base + cols]) / cols
        var = sum((x.data[base + c] - mean) ** 2 for c in range(cols)) / cols
        inv = 1.0 / math.sqrt(var + eps)
        inv_std[r] = inv
        for c in range(cols):
            xh = (x.data[base + c] - mean) * inv
            xhat[base + c] = xh
            out_data[base + c] = xh * g.data[c] + b.data[c]
    out = _make(out_data, x.shape, (x, g, b),
                x.requires_grad or g.requires_grad or b.requires_grad)
    def backward() -> None:
        # dxhat = dy * g ; dx = inv/D * (D*dxhat - sum(dxhat) - xhat*sum(dxhat*xhat))
        for r in range(rows):
            base = r * cols
            dxhat = [out.grad[base + c] * g.data[c] for c in range(cols)]
            s1 = sum(dxhat)
            s2 = sum(dxhat[c] * xhat[base + c] for c in range(cols))
            if x.requires_grad:
                for c in range(cols):
                    dx = inv_std[r] / cols * (cols * dxhat[c] - s1 - xhat[base + c] * s2)
                    x.grad[base + c] += dx
            if g.requires_grad:
                for c in range(cols):
                    g.grad[c] += out.grad[base + c] * xhat[base + c]
            if b.requires_grad:
                for c in range(cols):
                    b.grad[c] += out.grad[base + c]
    out._backward = backward
    return out


def softmax_rows(x: Tensor) -> Tensor:
    assert len(x.shape) == 2
    rows, cols = x.shape
    out_data = [0.0] * (rows * cols)
    for r in range(rows):
        base = r * cols
        m = max(x.data[base:base + cols])
        ex = [math.exp(x.data[base + c] - m) for c in range(cols)]
        s = sum(ex)
        for c in range(cols):
            out_data[base + c] = ex[c] / s
    out = _make(out_data, x.shape, (x,), x.requires_grad)
    def backward() -> None:
        if x.requires_grad:
            for r in range(rows):
                base = r * cols
                dot = sum(out.grad[base + c] * out_data[base + c] for c in range(cols))
                for c in range(cols):
                    dx = out_data[base + c] * (out.grad[base + c] - dot)
                    x.grad[base + c] += dx
    out._backward = backward
    return out


def embedding(w: Tensor, idx: Sequence[int]) -> Tensor:
    assert len(w.shape) == 2
    rows = len(idx)
    cols = w.shape[1]
    data = []
    for t in idx:
        base = t * cols
        data.extend(w.data[base:base + cols])
    out = _make(data, (rows, cols), (w,), w.requires_grad)
    def backward() -> None:
        if w.requires_grad:
            for r, t in enumerate(idx):
                base = t * cols
                for c in range(cols):
                    w.grad[base + c] += out.grad[r * cols + c]
    out._backward = backward
    return out


def cross_entropy(logits: Tensor, targets: Sequence[int]) -> Tensor:
    assert len(logits.shape) == 2 and logits.shape[0] == len(targets)
    rows, cols = logits.shape
    probs = [0.0] * (rows * cols)
    loss = 0.0
    for r in range(rows):
        base = r * cols
        m = max(logits.data[base:base + cols])
        ex = [math.exp(logits.data[base + c] - m) for c in range(cols)]
        s = sum(ex)
        for c in range(cols):
            probs[base + c] = ex[c] / s
        loss -= math.log(probs[base + targets[r]] + 1e-12)
    loss /= rows
    out = _make([loss], (1,), (logits,), logits.requires_grad)
    def backward() -> None:
        if logits.requires_grad:
            g = out.grad[0] / rows
            for r in range(rows):
                base = r * cols
                for c in range(cols):
                    logits.grad[base + c] += g * (probs[base + c] - (1.0 if c == targets[r] else 0.0))
    out._backward = backward
    return out


def backward(loss: Tensor) -> None:
    topo: list[Tensor] = []
    seen: set[int] = set()
    def build(t: Tensor) -> None:
        if id(t) in seen:
            return
        seen.add(id(t))
        for p in t._prev:
            build(p)
        topo.append(t)
    build(loss)
    loss.grad = [1.0]
    for t in reversed(topo):
        t._backward()


def causal_mask(t: int) -> list[bool]:
    """True means 'mask this score out'."""
    return [j > i for i in range(t) for j in range(t)]
