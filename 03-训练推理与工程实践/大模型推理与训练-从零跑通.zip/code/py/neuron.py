"""The smallest possible training run: one neuron, two parameters.

This is the numerical example used in the book.  Run it before the Transformer
demo; every number in the first table is printed explicitly.
"""
import os
import sys

sys.path.insert(0, os.path.dirname(__file__))
from autograd import Tensor, add, mul, scale, backward


def loss_at(w: float, b: float, x: float = 2.0, y: float = 3.0) -> tuple[float, float]:
    pred = w * x + b
    diff = pred - y
    return diff * diff, pred


def main() -> None:
    w, b, x, y = 0.5, 0.0, 2.0, 3.0
    lr = 0.05
    print("=== one manual step ===")
    loss, pred = loss_at(w, b, x, y)
    dl_dpred = 2 * (pred - y)
    dl_dw = dl_dpred * x
    dl_db = dl_dpred
    print(f"forward: pred = {w}*{x} + {b} = {pred}")
    print(f"loss   = (pred - y)^2 = ({pred} - {y})^2 = {loss}")
    print(f"dL/dpred = 2*(pred-y) = {dl_dpred}")
    print(f"dL/dw = dL/dpred * x = {dl_dw}")
    print(f"dL/db = dL/dpred * 1 = {dl_db}")
    w1, b1 = w - lr * dl_dw, b - lr * dl_db
    loss1, pred1 = loss_at(w1, b1, x, y)
    print(f"update: w={w1}, b={b1}")
    print(f"new pred={pred1}, new loss={loss1}")

    print("\n=== 10 steps of gradient descent ===")
    print(f"{'step':>4} {'w':>10} {'b':>10} {'pred':>10} {'loss':>12}")
    w, b = 0.5, 0.0
    for step in range(11):
        loss, pred = loss_at(w, b, x, y)
        print(f"{step:4d} {w:10.6f} {b:10.6f} {pred:10.6f} {loss:12.8f}")
        g_w = 2 * (pred - y) * x
        g_b = 2 * (pred - y)
        w -= lr * g_w
        b -= lr * g_b

    print("\n=== numeric gradient check at w=0.5, b=0 ===")
    eps = 1e-6
    for name, val in [("w", 0.5), ("b", 0.0)]:
        if name == "w":
            l_plus, _ = loss_at(val + eps, 0.0, x, y)
            l_minus, _ = loss_at(val - eps, 0.0, x, y)
        else:
            l_plus, _ = loss_at(0.5, val + eps, x, y)
            l_minus, _ = loss_at(0.5, val - eps, x, y)
        print(f"{name}: numeric={(l_plus-l_minus)/(2*eps):.8f}")

    print("\n=== the same step through autograd ===")
    tw = Tensor([0.5], (1,), requires_grad=True)
    tb = Tensor([0.0], (1,), requires_grad=True)
    tx = Tensor([x], (1,))
    ty = Tensor([y], (1,))
    pred_t = add(mul(tw, tx), tb)
    diff = add(pred_t, scale(ty, -1.0))
    loss_t = mul(diff, diff)
    backward(loss_t)
    print(f"loss={loss_t.item():.6f}, dL/dw={tw.grad[0]:.6f}, dL/db={tb.grad[0]:.6f}")


if __name__ == "__main__":
    main()
