"""Single-machine inference demo: prefill, KV cache, decode, sampling.

Pure Python, float64, no third-party packages.  The same weights produced by
train.py are loaded from JSON, so the demo is a continuation of training.
"""
from __future__ import annotations

import argparse
import json
import math
import os
import random
import sys
import time
from dataclasses import dataclass, field
from typing import Dict, List, Sequence, Tuple

sys.path.insert(0, os.path.dirname(__file__))
from model import Config, load_weights, forward as autograd_forward


# ---------------------------------------------------------------------------
# raw matrix helpers (no autograd, float64)
# ---------------------------------------------------------------------------
def linear(x: List[List[float]], w: List[List[float]], b: List[float]) -> List[List[float]]:
    n, d = len(x), len(x[0])
    out_d = len(w[0])
    out = [[0.0] * out_d for _ in range(n)]
    for i in range(n):
        xi = x[i]
        oi = out[i]
        for k in range(d):
            a = xi[k]
            if a == 0.0:
                continue
            wk = w[k]
            for j in range(out_d):
                oi[j] += a * wk[j]
        for j in range(out_d):
            oi[j] += b[j]
    return out


def layernorm(x: List[List[float]], g: List[float], b: List[float],
              eps: float = 1e-5) -> List[List[float]]:
    out = []
    for row in x:
        mean = sum(row) / len(row)
        var = sum((v - mean) ** 2 for v in row) / len(row)
        inv = 1.0 / math.sqrt(var + eps)
        out.append([(v - mean) * inv * g[i] + b[i] for i, v in enumerate(row)])
    return out


def softmax(row: List[float]) -> List[float]:
    m = max(row)
    ex = [math.exp(v - m) for v in row]
    s = sum(ex)
    return [v / s for v in ex]


def relu(x: List[List[float]]) -> List[List[float]]:
    return [[v if v > 0 else 0.0 for v in row] for row in x]


def add_rows(a: List[List[float]], b: List[List[float]]) -> List[List[float]]:
    return [[x + y for x, y in zip(ra, rb)] for ra, rb in zip(a, b)]


def embed(table: List[List[float]], idx: Sequence[int]) -> List[List[float]]:
    return [table[i][:] for i in idx]


@dataclass
class KVCache:
    k: List[List[float]] = field(default_factory=list)
    v: List[List[float]] = field(default_factory=list)
    bytes_per_value: int = 8  # this demo uses float64

    @property
    def seq_len(self) -> int:
        return len(self.k)

    @property
    def nbytes(self) -> int:
        return 2 * self.seq_len * len(self.k[0]) * self.bytes_per_value if self.k else 0


def qkv(params: Dict[str, List], x: List[List[float]],
        cfg: Config) -> Tuple[List[List[float]], List[List[float]], List[List[float]]]:
    q = linear(x, params["wq"], params["bq"])
    k = linear(x, params["wk"], params["bk"])
    v = linear(x, params["wv"], params["bv"])
    return q, k, v


def attn_prefill(params: Dict[str, List], x: List[List[float]], cache: KVCache,
                 cfg: Config) -> List[List[float]]:
    q, k, v = qkv(params, x, cfg)
    t = len(x)
    d = cfg.n_embd
    scale = 1.0 / math.sqrt(d)
    out = [[0.0] * d for _ in range(t)]
    for i in range(t):
        scores = []
        for j in range(t):
            if j > i:
                scores.append(-1e30)
            else:
                scores.append(sum(q[i][z] * k[j][z] for z in range(d)) * scale)
        probs = softmax(scores)
        for z in range(d):
            out[i][z] = sum(probs[j] * v[j][z] for j in range(t))
    cache.k.extend([row[:] for row in k])
    cache.v.extend([row[:] for row in v])
    return out


def attn_decode(params: Dict[str, List], x: List[List[float]], cache: KVCache,
                cfg: Config) -> List[List[float]]:
    q, k, v = qkv(params, x, cfg)
    d = cfg.n_embd
    cache.k.append(k[0][:])
    cache.v.append(v[0][:])
    scale = 1.0 / math.sqrt(d)
    scores = [sum(q[0][z] * kk[z] for z in range(d)) * scale for kk in cache.k]
    probs = softmax(scores)
    out = [[sum(probs[j] * cache.v[j][z] for j in range(len(cache.v))) for z in range(d)]]
    return out


def block(params: Dict[str, List], x: List[List[float]], cache: KVCache,
          cfg: Config, prefill: bool) -> List[List[float]]:
    h = layernorm(x, params["ln1_g"], params["ln1_b"])
    a = attn_prefill(params, h, cache, cfg) if prefill else attn_decode(params, h, cache, cfg)
    y = linear(a, params["wo"], params["bo"])
    x = add_rows(x, y)
    h = layernorm(x, params["ln2_g"], params["ln2_b"])
    h = relu(linear(h, params["w1"], params["b1"]))
    h = linear(h, params["w2"], params["b2"])
    x = add_rows(x, h)
    return layernorm(x, params["lnf_g"], params["lnf_b"])


def logits_from_hidden(params: Dict[str, List], h: List[List[float]],
                       cfg: Config) -> List[float]:
    return linear(h, params["lm_head"], params["lm_b"])[-1]


def prefill(params: Dict[str, List], tokens: Sequence[int], cfg: Config,
            cache: KVCache | None = None) -> Tuple[List[float], KVCache]:
    cache = cache or KVCache()
    x = embed(params["tok_emb"], tokens)
    pos = embed(params["pos_emb"], list(range(len(tokens))))
    x = add_rows(x, pos)
    h = block(params, x, cache, cfg, prefill=True)
    return logits_from_hidden(params, h, cfg), cache


def decode(params: Dict[str, List], token: int, pos: int, cfg: Config,
           cache: KVCache) -> List[float]:
    x = [[params["tok_emb"][token][j] + params["pos_emb"][pos][j]
          for j in range(cfg.n_embd)]]
    h = block(params, x, cache, cfg, prefill=False)
    return logits_from_hidden(params, h, cfg)


def full_logits(params: Dict[str, List], tokens: Sequence[int], cfg: Config) -> List[float]:
    """Recompute the whole prefix without a cache, for verification."""
    cache = KVCache()
    logits, _ = prefill(params, tokens, cfg, cache)
    return logits


def sample(logits: List[float], temperature: float, top_k: int, top_p: float,
           rng: random.Random) -> Tuple[int, List[Tuple[int, float]]]:
    if temperature <= 0:
        probs = softmax(logits)
        best = max(range(len(probs)), key=lambda i: probs[i])
        return best, sorted([(i, probs[i]) for i in range(len(probs))],
                            key=lambda x: -x[1])[:5]
    scaled = [z / temperature for z in logits]
    order = sorted(range(len(scaled)), key=lambda i: -scaled[i])
    if top_k > 0:
        order = order[:top_k]
    probs = softmax([scaled[i] for i in order])
    if top_p < 1.0:
        keep, acc = [], 0.0
        for i, p in zip(order, probs):
            keep.append(i)
            acc += p
            if acc >= top_p:
                break
        order = keep
        probs = softmax([scaled[i] for i in order])
    r = rng.random()
    acc = 0.0
    pick = order[0]
    for i, p in zip(order, probs):
        acc += p
        if r <= acc:
            pick = i
            break
    return pick, sorted([(i, p) for i, p in zip(order, probs)], key=lambda x: -x[1])[:5]


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--weights", default=os.path.join(os.path.dirname(__file__), "..", "weights", "tiny_py.json"))
    ap.add_argument("--prompt", default="the cat ")
    ap.add_argument("--n", type=int, default=24)
    ap.add_argument("--temperature", type=float, default=0.7)
    ap.add_argument("--top-k", type=int, default=6)
    ap.add_argument("--top-p", type=float, default=1.0)
    ap.add_argument("--seed", type=int, default=7)
    ap.add_argument("--log", default=os.path.join(os.path.dirname(__file__), "..", "out", "infer_python.txt"))
    args = ap.parse_args()

    cfg, vocab, tensors = load_weights(args.weights)
    params = {}
    for name, t in tensors.items():
        if len(t.shape) == 1:
            params[name] = t.data[:]
        else:
            rows, cols = t.shape
            params[name] = [t.data[r * cols:(r + 1) * cols] for r in range(rows)]
    stoi = {c: i for i, c in enumerate(vocab)}
    prompt_ids = [stoi[c] for c in args.prompt]
    if len(prompt_ids) >= cfg.block_size:
        raise SystemExit(f"prompt too long: {len(prompt_ids)} >= block_size {cfg.block_size}")
    rng = random.Random(args.seed)

    lines: List[str] = []
    def say(s: str = "") -> None:
        print(s)
        lines.append(s)

    say(f"model: {cfg.n_layer} layer, {cfg.n_head} head, d_model={cfg.n_embd}, "
        f"ff={cfg.d_ff}, vocab={cfg.vocab_size}, block={cfg.block_size}")
    say(f"params: {sum(len(x) if isinstance(x[0], float) else len(x) * len(x[0]) for x in params.values())}")
    say(f"prompt: {args.prompt!r} -> {len(prompt_ids)} tokens {prompt_ids}")
    say("")

    t0 = time.perf_counter()
    logits, cache = prefill(params, prompt_ids, cfg)
    t_prefill = (time.perf_counter() - t0) * 1000
    first, top = sample(logits, args.temperature, args.top_k, args.top_p, rng)
    ids = list(prompt_ids) + [first]
    say(f"prefill: {len(prompt_ids)} tokens in {t_prefill:.3f} ms; "
        f"first token {vocab[first]!r}; cache {cache.seq_len} tokens, {cache.nbytes} bytes (float64)")
    say(f"  top-5: " + ", ".join(f"{vocab[i]!r}:{p:.4f}" for i, p in top))
    say("")
    say(f"{'step':>4} {'token':>5} {'p(top1)':>8} {'cache':>6} {'ms':>7}  top-3")
    step_times = []
    for step in range(args.n):
        t = time.perf_counter()
        logits = decode(params, ids[-1], len(ids) - 1, cfg, cache)
        nxt, top = sample(logits, args.temperature, args.top_k, args.top_p, rng)
        dt = (time.perf_counter() - t) * 1000
        step_times.append(dt)
        ids.append(nxt)
        top3 = ", ".join(f"{vocab[i]!r}:{p:.3f}" for i, p in top[:3])
        say(f"{step:4d} {vocab[nxt]!r:>5} {top[0][1]:8.4f} {cache.seq_len:6d} {dt:7.3f}  {top3}")
        if vocab[nxt] == "." and step > 2:
            break

    text = "".join(vocab[i] for i in ids)
    say("")
    say(f"output: {text!r}")
    say(f"decode: {len(step_times)} steps, mean {sum(step_times)/len(step_times):.3f} ms/token, "
        f"total {sum(step_times):.3f} ms")
    say(f"KV cache final: {cache.seq_len} tokens, {cache.nbytes} bytes "
        f"({cache.nbytes/1024:.1f} KiB, float64)")

    # -------- verification: cached logits must equal full recomputation --------
    say("")
    say("verification: compare cached decode with full recomputation")
    cache2 = KVCache()
    prefill(params, prompt_ids, cfg, cache2)
    max_diff = 0.0
    for step in range(min(len(step_times), 12)):
        cached = decode(params, ids[len(prompt_ids) + step],
                        len(prompt_ids) + step, cfg, cache2)
        full = full_logits(params, ids[:len(prompt_ids) + step + 1], cfg)
        diff = max(abs(a - b) for a, b in zip(cached, full))
        max_diff = max(max_diff, diff)
        say(f"  pos {len(prompt_ids)+step:2d}: max|cached-full| = {diff:.3e}")
    say(f"  max diff over checked positions = {max_diff:.3e}")

    # -------- timing: cache vs recompute --------
    def run_cached() -> float:
        c = KVCache()
        lg, _ = prefill(params, prompt_ids, cfg, c)
        t = time.perf_counter()
        for step in range(24):
            lg = decode(params, ids[step % len(ids)], len(prompt_ids) + step, cfg, c)
        return (time.perf_counter() - t) * 1000

    def run_full() -> float:
        seq = list(prompt_ids)
        t = time.perf_counter()
        for step in range(24):
            seq.append(ids[step % len(ids)])
            lg = full_logits(params, seq, cfg)
        return (time.perf_counter() - t) * 1000

    tc, tf = run_cached(), run_full()
    say("")
    say(f"timing (24 decode steps): cached={tc:.2f} ms, full-recompute={tf:.2f} ms, "
        f"speedup={tf/tc:.2f}x")

    os.makedirs(os.path.dirname(args.log), exist_ok=True)
    open(args.log, "w", encoding="utf-8").write("\n".join(lines) + "\n")
    say(f"log written to {args.log}")


if __name__ == "__main__":
    main()
