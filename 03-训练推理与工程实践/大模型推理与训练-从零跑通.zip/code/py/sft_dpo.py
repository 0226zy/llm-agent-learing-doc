"""Two small calculations that explain SFT loss masking and DPO."""
import math


def sft_demo():
    tokens = ["<s>", "1", "+", "1", "=", "?", "2", "</s>"]
    labels = ["-100", "-100", "-100", "-100", "-100", "-100", "2", "</s>"]
    logp = [-0.1, -0.2, -0.3, -0.1, -0.2, -0.4, -0.05, -0.02]
    all_loss = -sum(logp) / len(logp)
    answer_idx = [i for i, lab in enumerate(labels) if lab != "-100"]
    masked_loss = -sum(logp[i] for i in answer_idx) / len(answer_idx)
    print("=== SFT loss mask ===")
    print(f"{'pos':>3} {'token':>7} {'label':>7} {'log p':>8} {'counted':>8}")
    for i, (t, lab, lp) in enumerate(zip(tokens, labels, logp)):
        print(f"{i:3d} {t:>7} {lab:>7} {lp:8.3f} {str(lab != '-100'):>8}")
    print(f"loss over all positions:  {all_loss:.4f}")
    print(f"loss over answer only:    {masked_loss:.4f}")
    print("Only the two answer tokens contribute; the prompt is context, not a target.")


def sigmoid(x):
    return 1 / (1 + math.exp(-x))


def dpo_demo():
    print("\n=== DPO loss ===")
    # average log-probabilities of the chosen and rejected answers
    logp_w, logp_l = -0.20, -0.60
    ref_w, ref_l = -0.30, -0.40
    print(f"policy:  logp(chosen)={logp_w}, logp(rejected)={logp_l}")
    print(f"reference: logp(chosen)={ref_w}, logp(rejected)={ref_l}")
    print(f"{'beta':>6} {'margin':>9} {'loss':>9}")
    for beta in [0.1, 0.5, 1.0, 2.0]:
        margin = beta * ((logp_w - logp_l) - (ref_w - ref_l))
        loss = -math.log(sigmoid(margin))
        print(f"{beta:6.1f} {margin:9.4f} {loss:9.4f}")
    print("The policy is pushed to increase the chosen-vs-rejected margin")
    print("relative to the frozen reference model.")


if __name__ == "__main__":
    sft_demo()
    dpo_demo()
