"""Symmetric int8 weight quantization on the tiny model.

Weights are quantized; LayerNorm parameters and embeddings stay in float64
(this mirrors W8A16 weight-only quantization).  The script reports the logit
change and how often the top-1 token is preserved.
"""
import math
import os
import sys

sys.path.insert(0, os.path.dirname(__file__))
import infer
from model import load_weights


def q_tensor(mat, per_channel=False):
    rows, cols = len(mat), len(mat[0])
    out = [[0.0] * cols for _ in range(rows)]
    scales = []
    for r in range(rows):
        row = mat[r]
        if per_channel:
            scale = max(abs(v) for v in row) / 127.0 or 1e-12
            scales.append(scale)
            for c, v in enumerate(row):
                out[r][c] = round(v / scale) * scale
        else:
            for c, v in enumerate(row):
                out[r][c] = v
    if not per_channel:
        scale = max(abs(v) for row in mat for v in row) / 127.0 or 1e-12
        scales = [scale]
        out = [[round(v / scale) * scale for v in row] for row in mat]
    return out, scales


def main():
    cfg, vocab, tensors = load_weights(os.path.join(os.path.dirname(__file__), "..", "weights", "tiny_py.json"))
    raw = {}
    for name, t in tensors.items():
        if len(t.shape) == 1:
            raw[name] = t.data[:]
        else:
            r, c = t.shape
            raw[name] = [t.data[i * c:(i + 1) * c] for i in range(r)]
    prompt = [14, 7, 5, 0, 3, 2, 14, 0]
    base_logits, _ = infer.prefill(raw, prompt, cfg)
    base_probs = infer.softmax(base_logits)
    base_top = sorted(range(len(base_probs)), key=lambda i: -base_probs[i])[:5]

    for mode, per_channel in [("per-tensor", False), ("per-channel", True)]:
        q = dict(raw)
        print(f"\n=== {mode} int8 quantization (weights only) ===")
        print(f"{'tensor':>10} {'max|w|':>9} {'scale':>9} {'max err':>9}")
        for name in ["wq", "wk", "wv", "wo", "w1", "w2", "lm_head"]:
            m = raw[name]
            qm, scales = q_tensor(m, per_channel)
            q[name] = qm
            max_w = max(abs(v) for row in m for v in row)
            max_err = max(abs(a - b) for ra, rb in zip(m, qm) for a, b in zip(ra, rb))
            print(f"{name:>10} {max_w:9.4f} {scales[0]:9.5f} {max_err:9.5f}")
        qlogits, _ = infer.prefill(q, prompt, cfg)
        qprobs = infer.softmax(qlogits)
        qtop = sorted(range(len(qprobs)), key=lambda i: -qprobs[i])[:5]
        max_diff = max(abs(a - b) for a, b in zip(base_logits, qlogits))
        mean_diff = sum(abs(a - b) for a, b in zip(base_logits, qlogits)) / len(base_logits)
        print(f"max |logit diff| = {max_diff:.5f}, mean = {mean_diff:.5f}")
        print(f"top-1: base={vocab[base_top[0]]!r} quant={vocab[qtop[0]]!r} "
              f"{'MATCH' if base_top[0] == qtop[0] else 'DIFF'}")
        print(f"top-5 overlap = {len(set(base_top) & set(qtop))}/5")
        print(f"p(top1): base={base_probs[base_top[0]]:.4f} quant={qprobs[qtop[0]]:.4f}")

    n = sum(len(t.data) for t in tensors.values())
    print(f"\nwhole model: {n} params; float64={n*8/1024:.1f} KiB, "
          f"bf16={n*2/1024:.1f} KiB, int8+scales~={n/1024:.1f} KiB")


if __name__ == "__main__":
    main()
